package gov.nasa.worldwindx.applications.sar;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class RGridDialog extends JDialog implements ActionListener
{
	public RGridDialog(JFrame parent, String title) {
	    super(parent, title, true);
	    if (parent != null) {
	      Dimension parentSize = parent.getSize(); 
	      Point p = parent.getLocation(); 
	      setLocation(p.x + parentSize.width / 4, p.y + parentSize.height / 4);
	    }
	    
	    
	    JPanel locationPane = new JPanel();
	    locationPane.add(new JLabel("Enter Point: "));
	    JTextField loc = new JTextField();
	    locationPane.add(loc);
	    getContentPane().add(locationPane, BorderLayout.SOUTH);
	    
	    
	    JPanel gridDimensionPane = new JPanel();
	    gridDimensionPane.add(new JLabel("Enter Size: "));
	    JTextField loc2 = new JTextField();
	    gridDimensionPane.add(loc2);
	    getContentPane().add(gridDimensionPane, BorderLayout.SOUTH);
	  
	    
	    JPanel distancePane = new JPanel();
	    distancePane.add(new JLabel("Enter Dimensions: "));
	    JTextField loc3 = new JTextField();
	    distancePane.add(loc3);
	    getContentPane().add(distancePane, BorderLayout.SOUTH);
	    
	    
	    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	    pack(); 
	    setVisible(true);
	  }
	
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		
	}

}
