package gov.nasa.worldwindx.applications.sar.tracks;

import java.awt.Color;

import gov.nasa.worldwind.geom.LatLon;
/*
 * Each receptor is meant to be a ( LatLon, Color ) pair
 */
public class Receptor {
	
	LatLon x;
	Color y;
	double max = 0.0;//set it to 0 initially
	
	
	public Receptor( LatLon l, Color c)
	{
	
		this.x = l;
		this.y = c;
	}
	
	public Receptor( Receptor r)
	{
		this.x = r.getLoc();
		this.y = r.getCol();
	}
	
	public LatLon getLoc()
	{
		return x;
	}
	
	public Color getCol()
	{
		return y;
	}
	
	
	public void setLoc( LatLon l )
	{
		this.x = l;
	}
	
	public void setCol( Color c )
	{
		this.y = c;
	}
	
	public double getMax()
	{
		return max;
	}
	
	public void setMax(double d)
	{
		this.max = d;
	}

}
