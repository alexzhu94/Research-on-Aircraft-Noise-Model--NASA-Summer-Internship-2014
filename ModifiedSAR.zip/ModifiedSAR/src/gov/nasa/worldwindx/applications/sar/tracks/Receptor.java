package gov.nasa.worldwindx.applications.sar.tracks;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;

import gov.nasa.worldwind.geom.LatLon;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.globes.Earth;
/*
 * Each receptor is meant to be a ( LatLon, Color ) pair
 */
public class Receptor {
	
	LatLon x;
	Color y;
	double max = 0.0;//set it to 0 initially
	double curr = 0.0;
	
	double sum = 0.0;
	double SEL = 0.0;
	
	//ArrayList<Double> decibels = new ArrayList<Double>();
	
	
	HashMap<Integer, Double> decibels = new HashMap<Integer, Double>();
	
	
	
	
	public Receptor( LatLon l, Color c)
	{
	
		this.x = l;
		this.y = c;
	}
	
	public Receptor( Receptor r)
	{
		this.x = r.getLoc();
		this.y = r.getCol();
	}
	
	public LatLon getLoc()
	{
		return x;
	}
	
	public Color getCol()
	{
		return y;
	}
	
	
	public void setLoc( LatLon l )
	{
		this.x = l;
	}
	
	public void setCol( Color c )
	{
		this.y = c;
	}
	
	public double getMax()
	{
		return max;
	}
	
	public void setMax(double d)
	{
		this.max = d;
	}
	
	public void setCurr(double d)
	{
		this.curr = d;
	}
	
	public double getCurr()
	{
		return this.curr;
	}
	
	/*public void setSEL(double d)
	{
		this.SEL = d;
	}
	
	public double getSEL()
	{
		return this.SEL;
	}*/
	
	public void addToHM(int x, double d)
	{
		
		this.decibels.put( new Integer(x), new Double(d) );
		//the intention is to store the index along the track, and the 
		//noise level in decibels as a pair in a hashmap. The main
		//reason for this is that there's no real guarantee that 
	}
	
	/*public double calculateSEL( int x )
	{
		double sum = 0.0;
		int i = 0;
		while(  i <= x )
		{
			
			if(this.decibels.get(new Integer(i)) != null)//if the object exists, then we can add it in. 
			{
				double curr = this.decibels.get(new Integer(i));
				sum += Math.pow(10.0, (curr/10.0));

			}
			
			else
			{
				System.out.println("Please start the track at the beginning");
				return -1.0;//this is to indicate that the SEL doesn't exist yet, and that the user
				//needs to start the program at the beginning. 
				
			}
			i++;
			
		}
		
		return 10*(Math.log10(sum));
		
	}*/
	
	
	public void updateSEL( double noiseLevel , LatLon prevPos, LatLon currPos, double speed, boolean isForward)//, int index)
	{
		
		
		
		
		//speed is in kmh, the greatCircleDistance is in meters. but we want time in seconds
		
		if(isForward)
		{
		
			double speedInMS = 1000.0*speed/3600.0;
			double dTime = LatLon.greatCircleDistance(prevPos, currPos).radians * Earth.WGS84_EQUATORIAL_RADIUS/speedInMS;
			//double curr = this.decibels.get(new Integer(i));
			dTime = 1;
			
			//setting dTime to 1 for simplicity
			
			sum += Math.pow(10.0, (dTime*curr/10.0));
			this.SEL = 10*(Math.log10(sum));
			
			
			System.out.println(dTime + " " + curr + " " + this.SEL);
		}
		
		else
		{
			double speedInMS = 1000.0*speed/3600.0;
			double dTime = LatLon.greatCircleDistance(prevPos, currPos).radians * Earth.WGS84_EQUATORIAL_RADIUS/speedInMS;
			//double curr = this.decibels.get(new Integer(i));
			sum -= Math.pow(10.0, (dTime*curr/10.0));
			this.SEL = 10*(Math.log10(sum));
		}
		
		
		//System.out.println(dTime);
		
		//System.out.println(speed);
		
		
		/*this.sum = 0.0;
		int i = 0;
		while(  i <= index )
		{
			
			if(this.decibels.get(new Integer(i)) != null)//if the object exists, then we can add it in. 
			{
				double curr = this.decibels.get(new Integer(i));
				sum += Math.pow(10.0, (dTime*curr/10.0));
				
				//System.out.println(curr);
				

			}
			
			else
			{
				System.out.println("Please start the track at the beginning");
			    this.SEL = -1.0;//this is to indicate that the SEL doesn't exist yet, and that the user
				//needs to start the program at the beginning. 
				return;
			}
			i++;
			
		}
		
		//System.out.println(sum);
		
		this.SEL = 10*(Math.log10(sum));*/
		
		//System.out.println(this.SEL);
	}
	
	public double getSEL()
	{
		return this.SEL;
	}
	
	public double getSum()
	{
		return this.sum;
	}

}
