/*
 * Copyright (C) 2012 United States Government as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 */

package gov.nasa.worldwindx.applications.sar;

import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.geom.Angle;
import gov.nasa.worldwind.geom.LatLon;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.globes.Earth;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.render.BasicShapeAttributes;
import gov.nasa.worldwind.render.Material;
import gov.nasa.worldwind.render.Renderable;
import gov.nasa.worldwind.render.SurfaceCircle;
import gov.nasa.worldwind.render.SurfaceShape;
import gov.nasa.worldwind.util.*;
import gov.nasa.worldwindx.applications.sar.tracks.Receptor;

import javax.swing.*;
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * @author tag
 * @version $Id: TrackViewPanel.java 1171 2013-02-11 21:45:02Z dcollins $
 */
public class TrackViewPanel extends JPanel
{
    // SAR logical components.
    private AnalysisPanel analysisPanel;
    private SARTrack sarTrack;
    private PropertyChangeListener trackPropertyChangeListener;
    private String elevationUnit;
    private String angleFormat;
    // Viewing mode
    private String viewMode = VIEW_MODE_FREE;
    // "Position" panel components
    private boolean suspendPositionEvents = false;
    private double positionDelta = 0;
    private JLabel latLabel;
    private JLabel lonLabel;
    private JLabel altLabel;
    
    
    private JTextField greenThres; //= new JTextField(3);//going to be used to set the thresholds
    private JTextField yellowThres; //= new JTextField(3);//for green and yellow
    
    private JLabel greenThresDisplay;
    private JLabel yellowThresDisplay;
    
    
    private JButton changeMode;
    private JButton goBack;
    private JButton SEL;
    
    
    private JButton getThrust;
    private JButton getReceptors;
    
    
    private JLabel latReadout;
    private JLabel lonReadout;
    private JLabel altReadout;
    private JSpinner positionSpinner;
    private JSlider positionSlider;
    private JButton fastReverseButton;
    private JButton reverseButton;
    private JButton stopButton;
    private JButton forwardButton;
    private JButton fastForwardButton;
    
    
    private JButton positionAndSpeedButton;
    //private JLabel speedLabel;
    //private JSpinner speedSpinner;
    private JSpinner speedFactorSpinner;
    
    
    private JTextField recSizeThres; //= new JTextField(3);//for green and yellow
    
    private JLabel recSizeDisplay;
    
    private JButton shapeButton;
    
    
    private JButton saveButton;
    
    
    private JLabel displaySpeed;
    
    private JLabel currSpeed;
    
    private int currIndex = 0;
    
    private ArrayList<Double> speeds = new ArrayList<Double>();
    private boolean hasReadSpeeds = false;
    private boolean rereadingSpeeds = false;
    
    
    
    JFileChooser saveChooser;
    JFileChooser speedChooser;
    
    String saveFilePath;
    String speedFilePath;
    
    // "Player" logical components.
    private static final int PLAY_FORWARD = 1;
    private static final int PLAY_BACKWARD = -1;
    private static final int PLAY_STOP = 0;
    private int playMode = PLAY_STOP;
    private Timer player;
    private long previousStepTime = -1;
	private JButton setRecButton;

    public static final String POSITION_CHANGE = "TrackViewPanel.PositionChange";
    public static final String VIEW_CHANGE = "TrackViewPanel.ViewChange";
    public static final String VIEW_MODE_CHANGE = "TrackViewPanel.ViewModeChange";
    public static final String VIEW_MODE_EXAMINE = "TrackViewPanel.ViewModeExamine";
    public static final String VIEW_MODE_FOLLOW = "TrackViewPanel.ViewModeFollow";
    public static final String VIEW_MODE_FREE = "TrackViewPanel.ViewModeFree";
    public static final String SHOW_TRACK_INFORMATION = "TrackViewPanel.ShowTrackInformation";
    public static final String CURRENT_SEGMENT = "TrackViewPanel.CurrentSegment";

    public TrackViewPanel(AnalysisPanel analysisPanel)
    {
        this.analysisPanel = analysisPanel;
        initComponents();
        this.updateEnabledState();
        this.trackPropertyChangeListener = new PropertyChangeListener()
        {
            public void propertyChange(PropertyChangeEvent event)
            {
                if (event.getPropertyName().equals(TrackController.TRACK_MODIFY))
                {
                    updatePositionList(false);
                }
            }
        };
    }

    public WorldWindow getWwd()
    {
        return this.analysisPanel.getWwd();
    }

    public void setCurrentTrack(SARTrack sarTrack)
    {
        if (this.sarTrack != null)
        {
            this.sarTrack.removePropertyChangeListener(this.trackPropertyChangeListener);
        }
        this.sarTrack = sarTrack;
        if (this.sarTrack != null)
        {
            this.sarTrack.addPropertyChangeListener(this.trackPropertyChangeListener);
        }

        this.updatePositionList(true);
        this.updateEnabledState();
    }

    public String getElevationUnit()
    {
        return this.elevationUnit;
    }

    public void setElevationUnit(String elevationUnit)
    {
        this.elevationUnit = elevationUnit;
    }

    public String getAngleFormat()
    {
        return this.angleFormat;
    }

    public void setAngleFormat(String format)
    {
        this.angleFormat = format;
    }

    public String getViewMode()
    {
        return this.viewMode;
    }

    public void setViewMode(String viewMode)
    {
        if (this.viewMode.equals(viewMode))
            return;
        this.viewMode = viewMode;
        this.firePropertyChange(VIEW_CHANGE, -1, 0);
    }

    private void updatePositionList(boolean resetPosition)
    {
        String[] strings = new String[this.sarTrack != null ? this.sarTrack.size() : 0];

        for (int i = 0; i < strings.length; i++)
        {
            strings[i] = String.format("%,4d", i);
        }

        if (strings.length == 0)
            strings = new String[] {"   0"};

        int currentPosition = Math.min(this.getCurrentPositionNumber(), strings.length - 1);
        int currentSliderValue = this.positionSlider.getValue();
        this.positionSpinner.setModel(new SpinnerListModel(strings));
        this.positionSpinner.setValue(resetPosition ? strings[0] : strings[currentPosition]);
        this.positionSlider.setValue(resetPosition ? 0 : currentSliderValue);
    }

    private void setPositionSpinnerNumber(int n)
    {
        this.positionSpinner.setValue(String.format("%,4d", n));
    }
    
    
    public SARTrack getSarTrack()
    {
    	return this.sarTrack;
    }
    
    public void setSarTrack( SARTrack s)
    {
    	this.sarTrack = s;
    }

    private void updateEnabledState()
    {
        boolean state = this.sarTrack != null;

        this.positionSpinner.setEnabled(state);
        this.positionSlider.setEnabled(state);
        this.latLabel.setEnabled(state);
        this.lonLabel.setEnabled(state);
        this.altLabel.setEnabled(state);
        
        //this.greenThres.setEnabled(state);
        //this.yellowThres.setEnabled(state);

        this.fastReverseButton.setEnabled(state);
        this.reverseButton.setEnabled(state);
//        this.stopButton.setEnabled(state);
        this.forwardButton.setEnabled(state);
        this.fastForwardButton.setEnabled(state);
        //this.speedLabel.setEnabled(state);
        //this.speedSpinner.setEnabled(state);
        this.speedFactorSpinner.setEnabled(state);
        this.currSpeed.setEnabled(state);
        this.displaySpeed.setEnabled(state);
        
        this.shapeButton.setEnabled(state);
        
        this.setRecButton.setEnabled(state);
        
        //this.positionAndSpeedButton.setEnabled(state);

        this.updateReadout(this.sarTrack != null && sarTrack.size() > 0 ? sarTrack.get(0) : null);
    }

    private void positionSpinnerStateChanged()
    {
        if (!this.suspendPositionEvents)
        {
            setPositionDelta(getCurrentPositionNumber(), 0);
            this.firePropertyChange(POSITION_CHANGE, -1, 0);
        }
    }

    private void positionSliderStateChanged()
    {
        if (!this.suspendPositionEvents)
        {
            updatePositionDelta();
            this.firePropertyChange(POSITION_CHANGE, -1, 0);
        }
    }

    public int getCurrentPositionNumber()
    {
        Object o = this.positionSpinner.getValue();
        if (o == null)
            return -1;

        return Integer.parseInt(o.toString().trim().replaceAll(",", ""));
    }

    private boolean isLastPosition(int n)
    {
        return n >= this.sarTrack.size() - 1;
    }

    public double getPositionDelta()
    {
        // Portion of the current segment 0.0 .. 1.0
        return this.positionDelta;
    }

    private void updatePositionDelta()
    {
        // From UI control
        int i = this.positionSlider.getValue();
        int min = this.positionSlider.getMinimum();
        int max = this.positionSlider.getMaximum();
        this.positionDelta = (double) i / ((double) max - (double) min);
    }

    public void gotoTrackEnd()
    {
        if(this.sarTrack != null && this.sarTrack.size() > 0)
        {
            this.setPositionDelta(this.sarTrack.size() - 1, 0);
            this.firePropertyChange(POSITION_CHANGE, -1, 0);
        }
    }
    
    public void gotoTrackStart()
    {
        {
            if(this.sarTrack != null && this.sarTrack.size() > 0)
            {
                this.setPositionDelta(0, 0);
                this.firePropertyChange(POSITION_CHANGE, -1, 0);
            }
        }
    }

    public void setPositionDelta(int positionNumber, double positionDelta)
    {
        // Update UI controls without firing events
        this.suspendPositionEvents = true;
        {
            setPositionSpinnerNumber(positionNumber);
            int min = this.positionSlider.getMinimum();
            int max = this.positionSlider.getMaximum();
            int value = (int) (min + (double) (max - min) * positionDelta);
            this.positionSlider.setValue(value);
        }
        this.suspendPositionEvents = false;

        this.positionDelta = positionDelta;
    }

    public boolean isExamineViewMode()
    {
        return this.viewMode.equals(VIEW_MODE_EXAMINE);
    }

    public boolean isFollowViewMode()
    {
        return this.viewMode.equals(VIEW_MODE_FOLLOW);
    }

    public boolean isFreeViewMode()
    {
        return this.viewMode.equals(VIEW_MODE_FREE);
    }

    public void updateReadout(Position pos)
    {
        this.latReadout.setText(pos == null ? "" : SAR2.formatAngle(angleFormat, pos.getLatitude()));
        this.lonReadout.setText(pos == null ? "" : SAR2.formatAngle(angleFormat, pos.getLongitude()));

        if (SAR2.UNIT_IMPERIAL.equals(this.elevationUnit))
            this.altReadout.setText(
                pos == null ? "" : String.format("% 8.0f ft", SAR2.metersToFeet(pos.getElevation())));
        else // Default to metric units.
            this.altReadout.setText(pos == null ? "" : String.format("% 8.0f m", pos.getElevation()));

        //this.speedLabel.setText(SAR2.UNIT_IMPERIAL.equals(this.elevationUnit) ? "MPH: " : "KMH: ");
        
        
        greenThresDisplay.setText("Green Threshold: " + analysisPanel.getGThres());
        
        yellowThresDisplay.setText(" Yellow Threshold: " + analysisPanel.getYThres());
        
        recSizeDisplay.setText("The Receptor Size is: " + analysisPanel.getRecSize());
        
        
    }
    
   
    
    

    public double getSpeedKMH()
    {
        String speedValue = this.currSpeed.getText();//(String)this.speedSpinner.getValue();
        
       
        double speed = Double.parseDouble(speedValue)* getSpeedFactor();
        if (SAR2.UNIT_IMPERIAL.equals(this.elevationUnit))
            speed *= 1.609344; // mph to kmh
        return speed;
    	
    	
    	//return 200.0;
    }
    
    public double getSpeed()
    {
        String speedValue = this.currSpeed.getText();//(String)this.speedSpinner.getValue();
        
        
        double speed = Double.parseDouble(speedValue);
        if (SAR2.UNIT_IMPERIAL.equals(this.elevationUnit))
            speed *= 1.609344; // mph to kmh
        return speed;
    }

    public double getSpeedFactor()
    {
        String speedFactor = ((String)this.speedFactorSpinner.getValue()).replace("x", "");
        return Double.parseDouble(speedFactor);
    	
    
    }

    
    
    // Player Controls

    private void fastReverseButtonActionPerformed()
    {
        if (this.getCurrentPositionNumber() > 0)
            setPositionSpinnerNumber(this.getCurrentPositionNumber() - 1);
    }

    private void reverseButtonActionPerformed()
    {
        setPlayMode(PLAY_BACKWARD);
    }

    private void stopButtonActionPerformed()
    {
        setPlayMode(PLAY_STOP);
    }

    private void forwardButtonActionPerformed()
    {
        setPlayMode(PLAY_FORWARD);
    }

    private void fastForwardButtonActionPerformed()
    {
        if (!isLastPosition(this.getCurrentPositionNumber()))
            setPositionSpinnerNumber(this.getCurrentPositionNumber() + 1);
    }
    
    private void thresGActionPerformed(double a) throws IOException
    {
    	this.analysisPanel.setG(a);
    	
    }
    
    private void thresYActionPerformed(double a) throws IOException
    {
    	if( a > this.analysisPanel.getGThres() )
    	{
    		this.analysisPanel.setY(a);
    	}
    }
    
    private void recSizeActionPerformed(double a) throws IOException
    {
    	this.analysisPanel.setRecSize(a);
    	
    	this.analysisPanel.resetHasReadFile();
    	
    	
    	
    }
    
    private void SELActionPerformed() throws IOException
    {
    	this.analysisPanel.SELModeClicked();
    	this.SEL.setText("SEL Mode Pressed");
    	this.changeMode.setText( "Max Mode");
    	this.goBack.setText("Default Mode");
    }
    
    private void changeModeActionPerformed() throws IOException
    {
    	this.analysisPanel.changeModeClicked();
    	this.SEL.setText("SEL Mode");
    	this.changeMode.setText( "Max Mode Pressed");
    	this.goBack.setText("Default Mode");
    }
    
    private void defaultModeActionPerformed() throws IOException
    {
    	this.analysisPanel.defaultModeClicked();
    	this.SEL.setText("SEL Mode");
    	this.goBack.setText( "Default Mode Pressed");
    	this.changeMode.setText("Max Mode");
    }
    
    private void getThrustActionPerformed()
    {
    	this.analysisPanel.initThrustFile();
    }
    
    private void inputReceptorsActionPerformed()
    {
    	this.analysisPanel.initRecFile();
    }
    
    public void resetDefaultMode() throws IOException
    {
    	this.analysisPanel.defaultModeClicked();
    	this.SEL.setText("SEL Mode");
    	this.goBack.setText( "Default Mode Pressed");
    	this.changeMode.setText("Max Mode");
    }
    
    private void shapeButtonActionPerformed() throws IOException
    {
    	int i = this.analysisPanel.getShapeInd();
    	if(i == 0)
    	{
    		this.shapeButton.setText("Square");
    		this.analysisPanel.setShapeInd(1);
    		this.analysisPanel.resetHasReadFile();
    	}
    	else 
    	{
    		this.shapeButton.setText("Circle");
    		this.analysisPanel.setShapeInd(0);
    		
    		this.analysisPanel.resetHasReadFile();
    		
    	}
    }
    
    
    private void positionAndSpeedButtonActionPerformed() throws IOException
    {
    	this.analysisPanel.initSandPFile();

    }
    
    
    private void saveButtonActionPerformed() throws IOException
    {
    	//now we want to write to the file
    	this.initSaveFile();
    	File file = new File(saveFilePath);
		PrintWriter writer = new PrintWriter(file);
		writer.println("Latitude" + '\t' + "Longitude" + '\t' + "Decibels" );
		
		ArrayList<Receptor> grid = this.analysisPanel.getGrid();
		
		//if(this.analysisPanel.getMode())//this would mean that it is in changeMode
		
		for(Receptor g : grid)
		{
			double decibels;
			if(this.analysisPanel.getChangeMode())
			{
				decibels = g.getMax();
			}
			else if(this.analysisPanel.getDefaultMode())
			{
				decibels = g.getCurr();//get the max in changeMode, otherwise get curr. 
			}
			
			else
			{
				decibels = g.getSEL();
				
				//System.out.println("printed out SEL");
			}
			
			writer.print(g.getLoc().latitude.degrees);
			writer.print('\t');
			writer.print(g.getLoc().longitude.degrees);
			writer.print('\t');
			writer.print(decibels);

			writer.println();
			
		}

		writer.close();
    }
    
    private void setRecActionPerformed() throws IOException
    {
    	
    	//RGridDialog r = new RGridDialog((JFrame) this.getWwd(), "Input Receptor Grid Dimensions");
    	
    	this.analysisPanel.initSetRec();
    	
    }
    
    
    
    public void initSaveFile()
    {
    	saveChooser = new JFileChooser();
		int returnVal = saveChooser.showOpenDialog(this);
		
        if (returnVal == JFileChooser.APPROVE_OPTION) {
		saveFilePath = saveChooser.getSelectedFile().getAbsolutePath();
        }
    }
    
    public void initSpeedFile()
    {
    	speedChooser = new JFileChooser();
		int returnVal = speedChooser.showOpenDialog(this);
		
        if (returnVal == JFileChooser.APPROVE_OPTION) {
		speedFilePath = speedChooser.getSelectedFile().getAbsolutePath();
        }
        else
        {
        	speedFilePath = "src/SFOSpeeds.txt";
        }
    }
    
    
    public boolean isPlayerActive()
    {
        return this.playMode != PLAY_STOP;
    }

    private void setPlayMode(int mode)
    {
        this.playMode = mode;
        if (player == null)
            initPlayer();
        player.start();
    }

    private void initPlayer()
    {
        if (player != null)
            return;

        player = new Timer(50, new ActionListener()
        {
            // Animate the view motion by controlling the positionSpinner and positionDelta
            public void actionPerformed(ActionEvent actionEvent)
            {
                runPlayer();
            }
        });
    }

    private void runPlayer()
    {
        int positionNumber = getCurrentPositionNumber();
        double curDelta = getPositionDelta();
        double speedKMH = getSpeedKMH();

        if (this.playMode == PLAY_STOP)
        {
            this.stopButton.setEnabled(false);
            this.player.stop();
            this.previousStepTime = -1;
        }
        else if (this.playMode == PLAY_FORWARD)
        {
            this.stopButton.setEnabled(true);
            if (positionNumber >= (this.sarTrack.size() - 1))
            {
                setPositionDelta(this.sarTrack.size() - 1, 0);
                this.playMode = PLAY_STOP;
            }
            else
            {
                double distanceToGo = computeDistanceToGo(speedKMH);
                while (distanceToGo > 0)
                {
                    double segmentLength = this.analysisPanel.getSegmentLength(positionNumber);
                    if (segmentLength * curDelta + distanceToGo <= segmentLength)
                    {
                        // enough space inside this segment
                        curDelta += distanceToGo / segmentLength;
                        setPositionDelta(positionNumber, curDelta);
                        distanceToGo = 0;
                    }
                    else
                    {
                        // move to next segment
                        if (!this.isLastPosition(positionNumber + 1))
                        {
                            distanceToGo -= segmentLength * (1d - curDelta);
                            positionNumber++;
                            curDelta = 0;
                        }
                        else
                        {
                            // reached end of track
                            setPositionDelta(positionNumber + 1, 0);
                            this.playMode = PLAY_STOP;
                            break;
                        }
                    }
                }
                this.firePropertyChange(POSITION_CHANGE, -1, 0);
            }
        }
        else if (this.playMode == PLAY_BACKWARD)
        {
            this.stopButton.setEnabled(true);
            if (positionNumber <= 0 && curDelta <= 0)
            {
                setPositionDelta(0, 0);
                this.playMode = PLAY_STOP;
            }
            else
            {
                double distanceToGo = computeDistanceToGo(speedKMH);
                while (distanceToGo > 0)
                {
                    double segmentLength = this.analysisPanel.getSegmentLength(positionNumber);
                    if (segmentLength * curDelta - distanceToGo >= 0)
                    {
                        // enough space inside this segment
                        curDelta -= distanceToGo / segmentLength;
                        setPositionDelta(positionNumber, curDelta);
                        distanceToGo = 0;
                    }
                    else
                    {
                        // move to previous segment
                        if (positionNumber > 0)
                        {
                            distanceToGo -= segmentLength * curDelta;
                            positionNumber--;
                            curDelta = 1;
                        }
                        else
                        {
                            // reached start of track
                            setPositionDelta(0, 0);
                            this.playMode = PLAY_STOP;
                            break;
                        }
                    }
                }
                this.firePropertyChange(POSITION_CHANGE, -1, 0);
            }
        }
    }

    private double computeDistanceToGo(double speedKMH)
    {
        long stepTime = System.nanoTime();
        double distance = 0;
        if (this.previousStepTime > 0)
        {
            double ellapsedMillisec = (stepTime - this.previousStepTime) / 1e6;
            distance = speedKMH / 3600d * ellapsedMillisec; // meters
        }
        this.previousStepTime = stepTime;
        return distance;
    }

    private void initComponents()
    {
        //======== this ========
        this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));

        //======== "Position" Section ========
        Box positionPanel = Box.createVerticalBox();
        {
            //======== Position Readout ========
            JPanel readoutPanel = new JPanel(new GridLayout(1, 3, 0, 0)); // nrows, ncols, hgap, vgap
            readoutPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
            {
                //======== Latitude ========
                Box lat = Box.createHorizontalBox();
                {
                    lat.add(Box.createHorizontalGlue());
                    this.latLabel = new JLabel();
                    this.latLabel.setText("Lat:");
                    lat.add(this.latLabel);
                    lat.add(Box.createHorizontalStrut(3));

                    this.latReadout = new JLabel();
                    this.latReadout.setText("-90.0000");
                    lat.add(this.latReadout);
                    lat.add(Box.createHorizontalGlue());
                }
                readoutPanel.add(lat);

                //======== Longitude ========
                Box lon = Box.createHorizontalBox();
                {
                    lon.add(Box.createHorizontalGlue());
                    this.lonLabel = new JLabel();
                    this.lonLabel.setText("Lon:");
                    lon.add(this.lonLabel);
                    lon.add(Box.createHorizontalStrut(3));

                    //---- lonReadout ----
                    this.lonReadout = new JLabel();
                    this.lonReadout.setText("-180.0000");
                    lon.add(this.lonReadout);
                    lon.add(Box.createHorizontalGlue());
                }
                readoutPanel.add(lon);

                //======== Altitude ========
                Box alt = Box.createHorizontalBox();
                {
                    alt.add(Box.createHorizontalGlue());
                    this.altLabel = new JLabel();
                    this.altLabel.setText("Alt:");
                    alt.add(this.altLabel);
                    alt.add(Box.createHorizontalStrut(3));

                    this.altReadout = new JLabel();
                    this.altReadout.setText("50,000.000");
                    alt.add(this.altReadout);
                    alt.add(Box.createHorizontalGlue());
                }
                readoutPanel.add(alt);
            }
            positionPanel.add(readoutPanel);
            positionPanel.add(Box.createVerticalStrut(16));

            
            
            //======== Shape of Receptors ========
            Box shapePanel = Box.createHorizontalBox();
            shapePanel.setAlignmentX(Component.CENTER_ALIGNMENT);
            {
            	
  
                shapePanel.add(Box.createHorizontalGlue());
                //---- "shape" Button ----
                this.shapeButton = new JButton();
                this.shapeButton.setText("Circle");
                this.shapeButton.setEnabled(false);
                this.shapeButton.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        try {
							shapeButtonActionPerformed();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
                    }
                });
                shapePanel.add(this.shapeButton);
                shapePanel.add(Box.createHorizontalStrut(3));           
            
              	
                this.setRecButton = new JButton();
                this.setRecButton.setText("Set Receptors");
                this.setRecButton.setEnabled(false);
                this.setRecButton.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        try {
							setRecActionPerformed();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
                    }
                });
                shapePanel.add(this.setRecButton);
                shapePanel.add(Box.createHorizontalStrut(3));  
                
                
                
                
                shapePanel.add(Box.createHorizontalGlue());
                //---- "<<" Button ----
                this.positionAndSpeedButton = new JButton();
                this.positionAndSpeedButton.setText("Position and Speed");
                //this.positionAndSpeedButton.setEnabled(false);
                this.positionAndSpeedButton.setEnabled(true);
                this.positionAndSpeedButton.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        try {
							positionAndSpeedButtonActionPerformed();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
                    }
                });
                
                
                
                
                
                shapePanel.add(this.positionAndSpeedButton);
                shapePanel.add(Box.createHorizontalStrut(3));    
                
                
            }
            positionPanel.add(shapePanel);
            positionPanel.add(Box.createVerticalStrut(16));       

            
            //======== Position Spinner, Slider ========
            Box positionControlPanel = Box.createHorizontalBox();
            positionControlPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
            {
                //---- Position Spinner ----
                this.positionSpinner = new JSpinner();
                this.positionSpinner.setModel(new SpinnerListModel(new String[] {"   0"}));
                this.positionSpinner.setEnabled(false);
                Dimension size = new Dimension(50, this.positionSpinner.getPreferredSize().height);
                this.positionSpinner.setMinimumSize(size);
                this.positionSpinner.setPreferredSize(size);
                this.positionSpinner.setMaximumSize(size);
                
                
          
                this.positionSpinner.addChangeListener(new ChangeListener()
                {
                    public void stateChanged(ChangeEvent e)
                    {
                        positionSpinnerStateChanged();
                    }
                });
                
                //positionSpinner.setValue(0);
                positionControlPanel.add(this.positionSpinner, BorderLayout.WEST);
                positionControlPanel.add(Box.createHorizontalStrut(10));

                //---- Position Slider ----
                this.positionSlider = new JSlider();
                this.positionSlider.setMaximum(1000);
                this.positionSlider.setValue(0);
                this.positionSlider.setEnabled(false);
                this.positionSlider.addChangeListener(new ChangeListener()
                {
                    public void stateChanged(ChangeEvent e)
                    {
                        positionSliderStateChanged();
                    }
                });
                positionControlPanel.add(this.positionSlider, BorderLayout.CENTER);
            }
            positionPanel.add(positionControlPanel);
            positionPanel.add(Box.createVerticalStrut(16));

            //======== "VCR" Panel ========
            Box vcrPanel = Box.createHorizontalBox();
            vcrPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
            {
                vcrPanel.add(Box.createHorizontalGlue());
                //---- "<<" Button ----
                this.fastReverseButton = new JButton();
                this.fastReverseButton.setText("<<");
                this.fastReverseButton.setEnabled(false);
                this.fastReverseButton.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        fastReverseButtonActionPerformed();
                    }
                });
                vcrPanel.add(this.fastReverseButton);
                vcrPanel.add(Box.createHorizontalStrut(3));

                //---- "<" Button----
                this.reverseButton = new JButton();
                this.reverseButton.setText("<");
                this.reverseButton.setEnabled(false);
                this.reverseButton.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        reverseButtonActionPerformed();
                    }
                });
                vcrPanel.add(this.reverseButton);
                vcrPanel.add(Box.createHorizontalStrut(3));

                //---- "Stop" Button ----
                this.stopButton = new JButton();
                this.stopButton.setText("Stop");
                this.stopButton.setEnabled(false);
                this.stopButton.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        stopButtonActionPerformed();
                    }
                });
                vcrPanel.add(this.stopButton);
                vcrPanel.add(Box.createHorizontalStrut(3));

                //---- ">" Button ----
                this.forwardButton = new JButton();
                this.forwardButton.setText(">");
                this.forwardButton.setBorder(UIManager.getBorder("Button.border"));
                this.forwardButton.setEnabled(false);
                this.forwardButton.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        forwardButtonActionPerformed();
                    }
                });
                vcrPanel.add(this.forwardButton);
                vcrPanel.add(Box.createHorizontalStrut(3));

                //---- ">>" Button ----
                this.fastForwardButton = new JButton();
                this.fastForwardButton.setText(">>");
                this.fastForwardButton.setEnabled(false);
                this.fastForwardButton.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        fastForwardButtonActionPerformed();
                    }
                });
                vcrPanel.add(this.fastForwardButton);

                //--------
                vcrPanel.add(Box.createHorizontalGlue());
            }
            positionPanel.add(vcrPanel);
            positionPanel.add(Box.createVerticalStrut(16));

            //======== "Speed" Panel ========
            Box speedPanel = Box.createHorizontalBox();
            speedPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
            {
                //---- Speed Multiplier Spinner ----
                this.speedFactorSpinner = new JSpinner();
                this.speedFactorSpinner.setModel(new SpinnerListModel(
                    new String[] {"x.12", "x.25", "x.50", "x1", "x2", "x3", "x4", "x5", "x7", "x10"}));
                this.speedFactorSpinner.setValue("x1");
                this.speedFactorSpinner.setEnabled(false);
                Dimension size = new Dimension(60, this.speedFactorSpinner.getPreferredSize().height);
                this.speedFactorSpinner.setMinimumSize(size);
                this.speedFactorSpinner.setPreferredSize(size);
                this.speedFactorSpinner.setMaximumSize(size);
                speedPanel.add(this.speedFactorSpinner);
                speedPanel.add(Box.createHorizontalGlue());
                
                
                

                //---- Speed Label----
                this.displaySpeed = new JLabel();
                
                try {
					this.readSpeed();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                
                displaySpeed.setText("The Speed is:");
                displaySpeed.setVisible(true);
                displaySpeed.setEnabled(false);
                
                speedPanel.add(this.displaySpeed);
                
                speedPanel.add(Box.createHorizontalGlue());
                
                
                //---- Speed Label----
                this.currSpeed = new JLabel();
        
                
                int last = speeds.size() - 1;
                currSpeed.setText(speeds.get(last).toString());
                		
                currSpeed.setVisible(true);
                
                currSpeed.setEnabled(false);
                
                speedPanel.add(this.currSpeed);
                
                speedPanel.add(Box.createHorizontalGlue());
            }
            positionPanel.add(speedPanel);
            positionPanel.add(Box.createVerticalGlue());
            
            
            
            //=========RGY thresholds=========================================
            Box RGYControlPanel = Box.createHorizontalBox();
            positionControlPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
            {
                //---- Position Spinner ----
                this.greenThres = new JTextField();
                this.yellowThres = new JTextField();
                
                //so I'm going to design this such that the green threshold must be adjusted
                //before the y threshold is adjusted. 
                
                
                
                
                
                this.greenThres.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                    	try
                    	{
                    		String text = greenThres.getText();//obtain the text
                        
                    		Double thres = new Double(text);//obtain the double from the input
                        
                        
                    		try {
								thresGActionPerformed(thres.doubleValue());
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
                        
                    		greenThres.setText("");//clear the box
                    	}
                    	
                    	
                        catch(NumberFormatException n)
                        {
                        	System.out.println("Please enter valid double");
                        } 
                    }
                });
                
                
                
                this.yellowThres.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        String text = yellowThres.getText();//obtain the text
                        
                        try
                        {
                        	Double thres = new Double(text);//obtain the double from the input
                        	try {
								thresYActionPerformed(thres.doubleValue());
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
                        	yellowThres.setText("");
                        }
                        catch(NumberFormatException n)
                        {
                        	System.out.println("Please enter valid double");
                        }
                    }
                });
                
                
 
                RGYControlPanel.add(this.greenThres, BorderLayout.WEST);
                RGYControlPanel.add(this.yellowThres, BorderLayout.WEST);
                RGYControlPanel.add(Box.createHorizontalStrut(10));

           
                //RGYControlPanel.add(this.positionSlider, BorderLayout.CENTER);
            }
            positionPanel.add(RGYControlPanel);
            positionPanel.add(Box.createVerticalStrut(16));

            
            
            
            
            //========= threshold displays=========================================
            Box thresDisplayPanel = Box.createHorizontalBox();
            positionControlPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
            {
                //---- Position Spinner ----
                this.greenThresDisplay = new JLabel();
                this.yellowThresDisplay = new JLabel();
                
                
                greenThresDisplay.setText("Green Threshold: " + analysisPanel.getGThres());
                
                yellowThresDisplay.setText(" Yellow Threshold: " + analysisPanel.getYThres());
                
                //so I'm going to design this such that the green threshold must be adjusted
                //before the y threshold is adjusted. 

                thresDisplayPanel.add(this.greenThresDisplay, BorderLayout.WEST);
                thresDisplayPanel.add(this.yellowThresDisplay, BorderLayout.WEST);
                thresDisplayPanel.add(Box.createHorizontalStrut(10));

           
                //RGYControlPanel.add(this.positionSlider, BorderLayout.CENTER);
            }
            
            positionPanel.add(thresDisplayPanel);
            positionPanel.add(Box.createVerticalStrut(16));
            
            
            
            
            
            //=========RGY thresholds=========================================
            Box RSControlPanel = Box.createHorizontalBox();
            positionControlPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
            {
                //---- Position Spinner ----
                this.recSizeThres = new JTextField();
                
                
                //so I'm going to design this such that the green threshold must be adjusted
                //before the y threshold is adjusted. 

                this.recSizeThres.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        String text = recSizeThres.getText();//obtain the text
                        
                        try
                        {
                        	Double thres = new Double(text);//obtain the double from the input
                        	try {
								recSizeActionPerformed(thres.doubleValue());
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
                        	recSizeThres.setText("");
                        }
                        catch(NumberFormatException n)
                        {
                        	System.out.println("Please enter valid double");
                        }
                    }
                });
                
                
 
                
                RSControlPanel.add(this.recSizeThres, BorderLayout.WEST);
                RSControlPanel.add(Box.createHorizontalStrut(10));

           
                //RGYControlPanel.add(this.positionSlider, BorderLayout.CENTER);
            }
            positionPanel.add(RSControlPanel);
            positionPanel.add(Box.createVerticalStrut(16));

            
            
            
            
            //========= threshold displays=========================================
            Box RTDisplayPanel = Box.createHorizontalBox();
            positionControlPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
            {
                //---- Position Spinner ----
                this.recSizeDisplay = new JLabel();
                recSizeDisplay.setText(" The Receptor Size is: " + analysisPanel.getRecSize());
                //so I'm going to design this such that the green threshold must be adjusted
                //before the y threshold is adjusted. 
                RTDisplayPanel.add(this.recSizeDisplay, BorderLayout.WEST);
                RTDisplayPanel.add(Box.createHorizontalStrut(10));

            }
            
            positionPanel.add(RTDisplayPanel);
            positionPanel.add(Box.createVerticalStrut(16));
            
            
 
            
            //========= changeMode displays=========================================
            Box modePanel = Box.createHorizontalBox();
            positionControlPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
            {
                //---- Position Spinner ----
                this.changeMode = new JButton();
                this.goBack = new JButton();
                this.SEL = new JButton();
                
                
                this.changeMode.setText( "Max Mode");
                
                this.goBack.setText("Default");
                
                this.SEL.setText("SEL");
                
                this.changeMode.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        //fastForwardButtonActionPerformed();
                    	
                    	try {
							changeModeActionPerformed();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
                    	
                    }
                }); 
                
                this.SEL.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        //fastForwardButtonActionPerformed();
                    	
                    	try {
							SELActionPerformed();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
                    	
                    }
                });
                
                
                this.goBack.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        //fastForwardButtonActionPerformed();
                    	
                    	try {
							defaultModeActionPerformed();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
                    }
                });

                modePanel.add(this.changeMode, BorderLayout.WEST);
                modePanel.add(this.goBack, BorderLayout.WEST);
                modePanel.add(this.SEL, BorderLayout.WEST);
                modePanel.add(Box.createHorizontalStrut(10));

           
                //RGYControlPanel.add(this.positionSlider, BorderLayout.CENTER);
            }
            
            
            positionPanel.add(modePanel);
            positionPanel.add(Box.createVerticalStrut(16));
            
            

            //========= userInput button displays=========================================
            Box inputPanel = Box.createHorizontalBox();
            positionControlPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
            {
                //---- Position Spinner ----
                this.getThrust = new JButton();
                this.getReceptors = new JButton();//initialize buttons
                
                this.getThrust.setText( "Input Thrust File");
                
                this.getReceptors.setText(" Input Receptor File");
                
                
                
                this.getThrust.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {

                    	
                    	getThrustActionPerformed();
                    	
                    }
                }); 
                
                
                this.getReceptors.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    { 	
                    	inputReceptorsActionPerformed();
                    }
                });
                
                
                
                this.saveButton = new JButton();
                this.saveButton.setText( "Save");
                this.saveButton.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {

                    	try {
							saveButtonActionPerformed();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
                    	
                    	
                    }
                }); 

                inputPanel.add(this.getThrust, BorderLayout.WEST);
                inputPanel.add(this.getReceptors, BorderLayout.WEST);
                //inputPanel.add(Box.createHorizontalStrut(10));
                inputPanel.add(this.saveButton, BorderLayout.WEST);
                inputPanel.add(Box.createHorizontalStrut(10));

                //RGYControlPanel.add(this.positionSlider, BorderLayout.CENTER);
            }
            
            
            positionPanel.add(inputPanel);
            positionPanel.add(Box.createVerticalStrut(16));
            
            
            
            //========= userInput button displays=========================================
            /*Box savePanel = Box.createHorizontalBox();
            positionControlPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
            {
                //---- Position Spinner ----
                this.saveButton = new JButton();
                this.saveButton.setText( "Save");
                this.saveButton.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {

                    	try {
							saveButtonActionPerformed();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
                    	
                    	
                    }
                }); 


                savePanel.add(this.saveButton, BorderLayout.WEST);
                savePanel.add(Box.createHorizontalStrut(10));

           
                //RGYControlPanel.add(this.positionSlider, BorderLayout.CENTER);
            }*/
            
            
           // positionPanel.add(savePanel);
           // positionPanel.add(Box.createVerticalStrut(16));
            
            
        }
        positionPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        this.add(positionPanel);
        this.add(Box.createVerticalGlue());
    }
    
    public void setSpeedFilePath(String path)
    {
    	this.speedFilePath = path;
    	rereadingSpeeds = true;//if we have to be resetting the speedFilePath, then
    	//we must be rereading the speeds. 
    }
    
    
    public void updateCurrSpeed()
    {
    	
    	String val = (String)this.positionSpinner.getValue();
    	
    	String val2 = val.trim();
    	
    	int i = Integer.parseInt(val2);

    	this.currSpeed.setText(this.speeds.get(i).toString());
    	
    }
    
    
    

    
    public void readSpeed() throws IOException
    {
    	if(hasReadSpeeds == false)
   		{
	
    		this.initSpeedFile();
    		
   			BufferedReader reader = new BufferedReader(
   	   				new FileReader(speedFilePath));

   			//hard coding the speed values for now, but eventually I intend to have this work for any file, and have the user 
   			//select the file. However, I do think speed will have to be read out separately. Might want to put that in the README
   			
   			
   			reader.readLine();// consume the first line of the file, it's
   							// meant for labelling.

   			
   			
   			String line;
   			while ((line = reader.readLine()) != null) 
   			{
   				Double speed = new Double(line);
   				
   				speeds.add(speed);
   				

   			}
   			
   			hasReadSpeeds = true;//have to make sure we only read in the speeds once
   			
   	
   		}
    	
    	else if(rereadingSpeeds == true)
    	{
    		speeds.clear();
    		
   			BufferedReader reader = new BufferedReader(
   	   				new FileReader(speedFilePath));

   			//hard coding the speed values for now, but eventually I intend to have this work for any file, and have the user 
   			//select the file. However, I do think speed will have to be read out separately. Might want to put that in the README
   			
   			
   			reader.readLine();// consume the first line of the file, it's
   							// meant for labelling.

   			
   			
   			String line;
   			while ((line = reader.readLine()) != null) 
   			{
   				Double speed = new Double(line);
   				
   				speeds.add(speed);
   				

   			}
   			
   			rereadingSpeeds = false;//have to make sure we only read in the speeds once
    	}
   			
    }
    
    
    
    
    
    // *** Restorable interface ***

    public String getRestorableState()
    {
        RestorableSupport rs = RestorableSupport.newRestorableSupport();
        this.doGetRestorableState(rs, null);

        return rs.getStateAsXml();
    }

    public void restoreState(String stateInXml)
    {
        if (stateInXml == null)
        {
            String message = Logging.getMessage("nullValue.StringIsNull");
            Logging.logger().severe(message);
            throw new IllegalArgumentException(message);
        }

        RestorableSupport rs;
        try
        {
            rs = RestorableSupport.parse(stateInXml);
        }
        catch (Exception e)
        {
            // Parsing the document specified by stateInXml failed.
            String message = Logging.getMessage("generic.ExceptionAttemptingToParseStateXml", stateInXml);
            Logging.logger().severe(message);
            throw new IllegalArgumentException(message, e);
        }

        this.doRestoreState(rs, null);
        
        
    }

    protected void doGetRestorableState(RestorableSupport rs, RestorableSupport.StateObject context)
    {
        // Add state values
        rs.addStateValueAsInteger(context, "positionNumber", this.getCurrentPositionNumber());
        rs.addStateValueAsDouble(context, "positionDelta", this.getPositionDelta());
        rs.addStateValueAsString(context, "viewMode", this.getViewMode());
        rs.addStateValueAsString(context, "speed", (String)this.currSpeed.getText());
        
        //System.out.println((String)this.speedSpinner.getValue());
        
        rs.addStateValueAsString(context, "speedFactor", (String)this.speedFactorSpinner.getValue());
        
    
    }

    protected void doRestoreState(RestorableSupport rs, RestorableSupport.StateObject context)
    {
        // Retrieve state values
        Integer positionNumberState = rs.getStateValueAsInteger(context, "positionNumber");
        Double positionDeltaState = rs.getStateValueAsDouble(context, "positionDelta");
        if (positionNumberState != null && positionDeltaState != null)
            this.setPositionDelta(positionNumberState, positionDeltaState);

       
        
        
        rs.getStateObject(context, "speed").setValue((String)this.currSpeed.getText());
        //System.out.println((String)this.currSpeed.getText());
        
        String speedState = rs.getStateValueAsString(context, "speed");
        
        //System.out.println(speedState);
        
        if (speedState != null)
            this.currSpeed.setText(speedState);
		
        String speedFactorState = rs.getStateValueAsString(context, "speedFactor");
        if (speedFactorState != null)
            this.speedFactorSpinner.setValue(speedFactorState);
        
        
        
        /*rs.getStateObject(context, "shape").setValue((String)this.shapeSpinner.getValue());
        String shapeState = rs.getStateValueAsString(context,"shape");
        
        
        System.out.println(shapeState);
        
        if(shapeState != null)
        {
        	if(this.shapeSpinner.getValue().equals("circle"))
        	{
        		
        		System.out.println(this.shapeSpinner.getValue());
        		this.analysisPanel.setShapeInd(0);
        	}
        	else
        	{
        		this.analysisPanel.setShapeInd(1);
        	}
        }*/

        
        
        String viewModeState = rs.getStateValueAsString(context, "viewMode");
        if (viewModeState != null)
        {
            this.viewMode = viewModeState;
            // Update analysis panel
            this.firePropertyChange(VIEW_CHANGE, -1, 0);
            // Update tool bar
            this.getWwd().firePropertyChange(TrackViewPanel.VIEW_MODE_CHANGE, null, viewModeState);
        }
    }


}
