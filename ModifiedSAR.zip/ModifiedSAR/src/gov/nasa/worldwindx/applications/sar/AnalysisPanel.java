/*
 * Copyright (C) 2012 United States Government as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 */

package gov.nasa.worldwindx.applications.sar;

import gov.nasa.worldwind.*;
import gov.nasa.worldwind.render.BasicShapeAttributes;
import gov.nasa.worldwind.render.Material;
import gov.nasa.worldwind.render.Renderable;
import gov.nasa.worldwind.render.SurfaceCircle;
import gov.nasa.worldwind.render.SurfaceShape;
import gov.nasa.worldwind.render.SurfaceSquare;
import gov.nasa.worldwind.util.*;
import gov.nasa.worldwindx.applications.sar.render.*;
import gov.nasa.worldwindx.applications.sar.tracks.Receptor;
import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwind.event.*;
import gov.nasa.worldwindx.examples.ApplicationTemplate;
import gov.nasa.worldwind.geom.*;
import gov.nasa.worldwind.globes.Earth;
import gov.nasa.worldwind.globes.Globe;
import gov.nasa.worldwind.layers.*;
import gov.nasa.worldwind.view.orbit.*;

import javax.swing.*;
import javax.swing.Box;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author tag
 * @version $Id: AnalysisPanel.java 1171 2013-02-11 21:45:02Z dcollins $
 */
public class AnalysisPanel extends JPanel implements Restorable
{
    public static final String ANALYSIS_PANEL_STATE = "AnalysisPanelState";

    private WorldWindow wwd;
    private TrackController trackController;
    private SARTrack currentTrack;
    private TrackViewPanel trackViewPanel;
    private TerrainProfilePanel terrainProfilePanel;
    private JFrame terrainProfileFrame;
    private CloudCeilingPanel cloudCeilingPanel;
    private JFrame cloudCeilingFrame;

    private CrosshairLayer crosshairLayer;
    private boolean crosshairNeedsUpdate = false;
    private RenderableLayer trackRenderables;
    private PlaneModel planeModel;
    private TrackSegmentInfo segmentInfo;
    private String trackInfoState;

    private String lastUpdateViewMode;
    private ViewState examineViewState;
    
    
    private ArrayList <Receptor> grid = new ArrayList <Receptor> ();//receptor grid that will be used to store the receptors that need
    					//to be colored. 
    private Boolean hasReadFile = false;//this must be set to true, will ensure that we only 
    							//read the file once
    private double[][] decibels = new double[20][11];
    
    private Boolean hasReadThrust = false;
    
    private double[] dists = { 200.0, 400.0, 630.0, 1000.0, 2000.0, 4000.0, 6300.0, 10000.0, 16000.0, 25000.0 };
    
    private double thresG = 80.0;//will be the user threshold for red
    private double thresY = 95.0;//will be the user threshold for yellow
    
    private double recSize = 100.0;//this will set the receptor size
    
    
    private JFileChooser thrustChooser;
    private JFileChooser recChooser;
    
    private JFileChooser sAndPChooser;
    
    private String sAndPFilePath;
    
    private String recFilePath = "src/Receptor_Grid01_SFO.txt";
    private String thrustFilePath = "src/CF565C.txt";
    
    
    private SurfaceShape localObject;//this will change shape depending on input from the track panel, circle
    //and square for now are the available shapes. 
    
    private int shapeInd = 0;//will let the program know which shapeIndex we want. 
    
    
    HashMap<LatLon , SurfaceShape > hm = new HashMap<LatLon, SurfaceShape>();
    
    
    private boolean changeMode = false;//this is going to determine which mode we are in.
    private boolean SELMode = false;
    private boolean defaultMode = true;
    
    
    private boolean hasReadLast = false;
    
    
    ArrayList<SARPosition> positions;
    
    private Position prevPosition = null;
    
    

    
    
    
    //will use hm to pair latlon points with surfaceCircles, will remove and add pairs into this throughout the animation. 
    //the intention is to have this get rid of the mixing of colors when different colored circles are drawn on top of each other
    
    

    private final PropertyChangeListener propertyChangeListener = new PropertyChangeListener()
    {
        @SuppressWarnings({"StringEquality"})
        public void propertyChange(PropertyChangeEvent propertyChangeEvent)
        {
//            if (!(propertyChangeEvent.getPropertyName() == AVKey.VIEW
//                || propertyChangeEvent.getPropertyName() == AVKey.VIEW_QUIET))
//                System.out.println("AnalysisPanel.propertyChange() for " + propertyChangeEvent.getPropertyName() + " from " + propertyChangeEvent.getSource());

            if (propertyChangeEvent.getPropertyName() == TrackViewPanel.VIEW_CHANGE)
            {
                // When the view mode has changed, update the view parameters gradually.
                try {
					updateView(true);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
            else if (propertyChangeEvent.getPropertyName() == TrackViewPanel.POSITION_CHANGE)
            {
                // When the track position has changed, update the view parameters immediately.
                try {
					updateView(false);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                cloudCeilingPanel.setTrackCurrentPositionNumber(getCurrentPositionNumber());
            }
            else if (propertyChangeEvent.getPropertyName() == TrackController.TRACK_MODIFY)
            {
                // When the track has changed, update the view parameters immediately
                try {
					updateView(false);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                // Update the terrain profile path and cloud ceiling too.
                terrainProfilePanel.updatePath(currentTrack.getPositions());
                cloudCeilingPanel.setTrack(currentTrack);
                // If track is being extended goto track end
                if (getTrackController().isExtending() && trackViewPanel.isFreeViewMode())
                    gotoTrackEnd();
                	
                	//gotoTrackStart();
            }
            else if (propertyChangeEvent.getPropertyName() == AVKey.ELEVATION_MODEL
                && trackViewPanel.isExamineViewMode() && !wwd.getView().isAnimating())
            {
                // When the elevation model changes, and the view is examining the terrain beneath the track
                // (but has not active state iterators), update the view parameters immediately.
                try {
					updateView(false);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
            else if (propertyChangeEvent.getPropertyName() == SARKey.ELEVATION_UNIT)
            {
                updateElevationUnit(propertyChangeEvent.getNewValue());
            }
            else if (propertyChangeEvent.getPropertyName() == SARKey.ANGLE_FORMAT)
            {
                updateAngleFormat(propertyChangeEvent.getNewValue());
            }
            else if (propertyChangeEvent.getPropertyName() == TerrainProfilePanel.TERRAIN_PROFILE_OPEN)
            {
                terrainProfileFrame.setVisible(true);
            }
            else if (propertyChangeEvent.getPropertyName() == TerrainProfilePanel.TERRAIN_PROFILE_CHANGE)
            {
                wwd.redraw();
            }
            else if (propertyChangeEvent.getPropertyName() == CloudCeilingPanel.CLOUD_CEILING_OPEN)
            {
                cloudCeilingFrame.setVisible(true);
            }
            else if (propertyChangeEvent.getPropertyName() == CloudCeilingPanel.CLOUD_CEILING_CHANGE)
            {
                wwd.redraw();
            }
            else if (propertyChangeEvent.getPropertyName() == TrackViewPanel.VIEW_MODE_CHANGE)
            {
                trackViewPanel.setViewMode((String) propertyChangeEvent.getNewValue());
            }
            else if (propertyChangeEvent.getPropertyName() == TrackViewPanel.SHOW_TRACK_INFORMATION)
            {
                trackInfoState = (String) propertyChangeEvent.getNewValue();
                updateShowTrackInformation();
            }

            if ((propertyChangeEvent.getPropertyName() == AVKey.VIEW
                || propertyChangeEvent.getPropertyName() == AVKey.VIEW_QUIET)
                && trackViewPanel.isFollowViewMode())
            {
                doUpdateCrosshair();
            }
        }
    };

    private final RenderingListener renderingListener = new RenderingListener()
    {
        public void stageChanged(RenderingEvent event)
        {
            if (crosshairNeedsUpdate && event.getStage().equals(RenderingEvent.AFTER_BUFFER_SWAP))
            {
                doUpdateCrosshair();
            }
        }
    };

	private double prevSpeed;

    private class ViewState
    {
        public Angle pitch;
        public Angle relativeHeading;
        public double zoom;
        public LatLon relativeCenterLocation;

        public ViewState(OrbitView view, Angle referenceHeading, Position referencePosition)
        {
            this.pitch = view.getPitch();
            this.relativeHeading = view.getHeading().subtract(referenceHeading);
            this.zoom = view.getZoom();
            this.relativeCenterLocation = view.getCenterPosition().subtract(referencePosition);
        }

        public ViewState(Angle relativeHeading, Angle pitch, double zoom, LatLon relativeCenterPosition)
        {
            this.pitch = pitch;
            this.relativeHeading = relativeHeading;
            this.zoom = zoom;
            this.relativeCenterLocation = relativeCenterPosition;
        }
    }

    public AnalysisPanel()
    {
        this.initComponents();
        this.layoutComponents();

        // Init plane/segment info layer.
        this.planeModel = new PlaneModel(100d, 100d, Color.YELLOW);
        this.planeModel.setShadowScale(0.1);
        this.planeModel.setShadowColor(new Color(255, 255, 0, 192));
        this.segmentInfo = new TrackSegmentInfo();
        this.trackRenderables = new RenderableLayer();
        this.trackRenderables.addRenderable(this.planeModel);
        this.trackRenderables.addRenderable(this.segmentInfo);
        // Init crosshair layer
        this.crosshairLayer = new CrosshairLayer("images/64x64-crosshair.png");
        this.crosshairLayer.setOpacity(0.4);
        this.crosshairLayer.setEnabled(false);
        // Init terrain profile panel and frame
        this.terrainProfilePanel = new TerrainProfilePanel();
        this.terrainProfileFrame = new JFrame("Terrain Profile");
        this.terrainProfileFrame.setResizable(false);
        this.terrainProfileFrame.setAlwaysOnTop(true);
        this.terrainProfileFrame.add(this.terrainProfilePanel);
        this.terrainProfileFrame.pack();
        SAR2.centerWindowInDesktop(this.terrainProfileFrame);
        // Init cloud ceiling panel and frame
        this.cloudCeilingPanel = new CloudCeilingPanel();
        this.cloudCeilingFrame = new JFrame("Cloud Contour");
        this.cloudCeilingFrame.setResizable(false);
        this.cloudCeilingFrame.setAlwaysOnTop(true);
        this.cloudCeilingFrame.add(this.cloudCeilingPanel);
        this.cloudCeilingFrame.pack();
        SAR2.centerWindowInDesktop(this.cloudCeilingFrame);
        // Listen to track view panel and cloud ceiling panel
        this.trackViewPanel.addPropertyChangeListener(this.propertyChangeListener);
        this.cloudCeilingPanel.addPropertyChangeListener(this.propertyChangeListener);

        this.updateShowTrackInformation();
    }

    public void setWwd(WorldWindow wwd)
    {
        if (this.wwd != null)
        {
            this.wwd.removePropertyChangeListener(this.propertyChangeListener);
//            this.wwd.getModel().getGlobe().getElevationModel().removePropertyChangeListener(this.propertyChangeListener);
            this.wwd.getView().removePropertyChangeListener(this.propertyChangeListener);
            this.wwd.removeRenderingListener(this.renderingListener);
        }
        this.wwd = wwd;
        this.terrainProfilePanel.setWwd(wwd);
        if (this.wwd != null)
        {
            this.wwd.addPropertyChangeListener(this.propertyChangeListener);
//            this.wwd.getModel().getGlobe().getElevationModel().addPropertyChangeListener(this.propertyChangeListener);
            this.wwd.getView().addPropertyChangeListener(this.propertyChangeListener);
            this.wwd.addRenderingListener(this.renderingListener);
            ApplicationTemplate.insertBeforeCompass(wwd, this.trackRenderables);
            ApplicationTemplate.insertBeforeCompass(wwd, this.crosshairLayer);
            // Init cloud ceiling
            this.cloudCeilingPanel.setCloudCeiling(new CloudCeiling(this.wwd));
        }
    }

    public WorldWindow getWwd()
    {
        return this.wwd;
    }

    public TrackController getTrackController()
    {
        return this.trackController;
    }

    public void setTrackController(TrackController trackController)
    {
        this.trackController = trackController;
    }

    public String getViewMode()
    {
        return this.trackViewPanel.getViewMode();
    }

    public void setCurrentTrack(SARTrack currentTrack)
    {
        if (this.currentTrack != null)
        {
            this.currentTrack.removePropertyChangeListener(this.propertyChangeListener);
            this.currentTrack.setValue(ANALYSIS_PANEL_STATE, this.getRestorableState());
        }

        this.currentTrack = currentTrack;
        this.segmentInfo.setTrack(currentTrack);
        this.trackViewPanel.setCurrentTrack(currentTrack);

        if (this.currentTrack != null)
        {
            this.currentTrack.addPropertyChangeListener(this.propertyChangeListener);
            this.terrainProfilePanel.updatePath(currentTrack.getPositions());
            this.cloudCeilingPanel.setTrack(this.currentTrack);
            String stateInXML = (String) this.currentTrack.getValue(ANALYSIS_PANEL_STATE);
            if (stateInXML != null)
                this.restoreState(stateInXML);
        }
        
        if(this.currentTrack != null)
        {
        	this.positions = this.currentTrack.getPositions();//going to update the positions arrayList so that 
        	//I will have 
        }
        //this.trackController.addTrack(currentTrack);
        
        this.trackViewPanel.setSarTrack(currentTrack);
    }

    private void updateElevationUnit(Object newValue)
    {
        if (newValue != null)
        {
            this.segmentInfo.setElevationUnit(newValue);
            this.trackViewPanel.setElevationUnit(newValue.toString());
            this.trackViewPanel.updateReadout(this.getPositionAlongSegment());
            this.cloudCeilingPanel.setElevationUnit(newValue.toString());
        }
    }

    private void updateAngleFormat(Object newValue)
    {
        if (newValue != null)
        {
            this.segmentInfo.setAngleFormat(newValue);
            this.trackViewPanel.setAngleFormat(newValue.toString());
            this.trackViewPanel.updateReadout(this.getPositionAlongSegment());
        }
    }

    private Angle getControlHeading()
    {
        return Angle.ZERO;
    }

    @SuppressWarnings({"UnusedDeclaration"})
    private Angle getControlPitch()
    {
        return Angle.fromDegrees(80);
    }

    private Angle getControlFOV()
    {
        return Angle.fromDegrees(45);
    }

    private void updateView(boolean goSmoothly) throws IOException
    {
        //System.out.println("AnalysisPanel.updateView(" + goSmoothly + "): view mode: " + this.trackViewPanel.getViewMode());
        BasicOrbitView view = (BasicOrbitView) this.wwd.getView();
        view.setFieldOfView(this.getControlFOV());

        Position pos = this.getPositionAlongSegment();
        if (TrackViewPanel.VIEW_MODE_EXAMINE.equals(this.lastUpdateViewMode)
            && !this.trackViewPanel.getViewMode().equals(this.lastUpdateViewMode))
        {
            // Save examine mode view orientation when moving out of examine mode
            this.saveExamineViewState();
        }
        this.lastUpdateViewMode = this.trackViewPanel.getViewMode();

        if (pos != null)
        {
            Angle heading = this.getHeading().add(this.getControlHeading());

            this.terrainProfilePanel.updatePosition(pos, heading);
            this.planeModel.setPosition(pos);
            this.planeModel.setHeading(heading);

            if (this.trackViewPanel.isExamineViewMode())
            {
                this.crosshairLayer.setEnabled(false);  // Turn off crosshair
                this.terrainProfilePanel.setFollowObject();
                // Set the view center point to the current track position on the ground - spheroid.
                // This gets the eye looking at the cross section.
                Position groundPos = getSmoothedGroundPositionAlongSegment();
                if (groundPos == null)
                    groundPos = getGroundPositionAlongSegment();

                if (goSmoothly)
                {
                    Angle initialPitch = Angle.fromDegrees(Math.min(60, view.getPitch().degrees));
                    Angle initialHeading = view.getHeading();
                    double initialZoom = 10000;
                    if (this.examineViewState != null)
                    {
                        // Use previously saved view orientation values if available
                        initialPitch = this.examineViewState.pitch;
                        initialHeading = this.examineViewState.relativeHeading.add(this.getHeading());
                        initialZoom = this.examineViewState.zoom;
                    }
                    // If the player is active, set initial parameters immediately.
                    // Otherwise, set initial parameters gradually.
                    if (this.trackViewPanel.isPlayerActive())
                    {
                        view.setCenterPosition(groundPos);
                        view.setZoom(initialZoom);
                        view.setPitch(initialPitch);
                        view.setHeading(initialHeading);
                    }
                    else
                    {
                        // Stop all animations on the view, and start a 'pan to' animation.
                        view.stopAnimations();
                        view.addPanToAnimator(
                            groundPos, initialHeading, initialPitch, initialZoom, true);
                    }
                }
                else
                {
                    // Send a message to stop all changes to the view's center position.
                    view.stopMovementOnCenter();
                    // Set the view to center on the track position,
                    // while keeping the eye altitude constant.
                    try
                    {
                        Position eyePos = view.getCurrentEyePosition();
                        // New eye lat/lon will follow the ground position.
                        LatLon newEyeLatLon = eyePos.add(groundPos.subtract(view.getCenterPosition()));
                        // Eye elevation will not change unless it is below the ground position elevation.
                        double newEyeElev = eyePos.getElevation() < groundPos.getElevation() ?
                            groundPos.getElevation() : eyePos.getElevation();

                        Position newEyePos = new Position(newEyeLatLon, newEyeElev);
                        view.setOrientation(newEyePos, groundPos);
                    }
                    // Fallback to setting center position.
                    catch (Exception e)
                    {
                        view.setCenterPosition(groundPos);
                        // View/OrbitView will have logged the exception, no need to log it here.
                    }
                }
            }
            else if (this.trackViewPanel.isFollowViewMode())
            {
                Angle pitch = Angle.POS90;
                double zoom = 0;
                heading = getSmoothedHeading(.1); // smooth heading on first and last 10% of segment

                this.terrainProfilePanel.setFollowObject();

                // Place the eye at the track current lat-lon and altitude, with the proper heading
                // and pitch from slider. Intended to simulate the view from the plane.
                if (goSmoothly)
                {
                    // If the player is active, set initial parameters immediately.
                    // Otherwise, set initial parameters gradually.
                    if (this.trackViewPanel.isPlayerActive())
                    {
                        view.setCenterPosition(pos);
                        view.setHeading(heading);
                        view.setPitch(pitch);
                        view.setZoom(zoom);
                    }
                    else
                    {
                        // Stop all animations on the view, and start a 'pan to' animation.
                        view.stopAnimations();
                        view.addPanToAnimator(pos, heading, pitch, zoom);
                    }
                }
                else
                {
                    // Stop all view animations, and send a message to stop all changes to the view.
                    view.stopAnimations();
                    view.stopMovement();
                    // Set the view values to follow the track.
                    view.setCenterPosition(pos);
                    view.setHeading(heading);
                    view.setPitch(pitch);
                    view.setZoom(zoom);
                }
                // Update crosshair position
                this.updateCrosshair();
            }
            else if (this.trackViewPanel.isFreeViewMode())
            {
                this.crosshairLayer.setEnabled(false);  // Turn off crosshair
                if (goSmoothly)
                {
                    // Stop any state iterators, and any view movement.
                    view.stopAnimations();
                    view.stopMovement();
                    // Flag the OrbitView as 'out of focus'. This ensures that the center position will be updated
                    // just before the users next interaction with the view.
                    view.setViewOutOfFocus(true);
                }
            }
        }

        this.updateShowTrackInformation();
        this.segmentInfo.setSegmentIndex(this.getCurrentPositionNumber());
        this.segmentInfo.setSegmentPosition(pos);
        this.trackViewPanel.updateReadout(pos);
        
        
        this.trackViewPanel.updateCurrSpeed();
        
        
        if(pos != null)
        {
        
        	RenderableLayer layer = new RenderableLayer();
        	
        	if(this.recFilePath != null && this.thrustFilePath != null)
        	{
        		detReceptors( new LatLon(pos.latitude, pos.longitude), layer);
        		this.wwd.getModel().getLayers().add(layer);
        	}
        }
  
        this.wwd.redraw();
        
        this.prevPosition = pos;//update the previous position so that we can use it later.
        this.prevSpeed = this.trackViewPanel.getSpeed();
        
        //System.out.println(prevSpeed);
    }
    
    
    
    /*
     * will allow me to keep track of the grid. 
     */
    public ArrayList<Receptor> getGrid()
    {
    	return this.grid;
    }
    
    
    /*
     * set the green threshold
     */
    public void setG( double a ) throws IOException
    {

    	this.thresG = a;//the expectation is that all the checks will have been performed in the TrackViewPanel prior to calling
    	//setG or setY. 
    	this.updateView(true);
    }
    
    
    /*
     *  set the yellow threshold
     */
    
    public void setY ( double a ) throws IOException
    
    {

        this.thresY = a;
    	
        this.updateView(true);    	
    }
    
    /*
     * need getters for the G and Y threshold values as well, so we can perform the checks
     * at in the TrackViewPanel
     * 
     * 
     */
    public double getYThres()
    {
    	return this.thresY;
    }
    
    
    /*
     * obtain the G threshold 
     */
    public double getGThres()
    {
    	return this.thresG;
    }
    
    /*
     * if the changeMode button has been clicked, then we need to set the boolean to true. 
     * 
     */
    
    public void changeModeClicked() throws IOException
    {
    	this.changeMode = true;
    	this.defaultMode = false;
    	this.SELMode = false;
    	
    	this.updateView(true);
    }
    
    
    /*
     * setting changeMode to false will get us back to the default. 
     */
    public void defaultModeClicked() throws IOException
    {
    	
    	this.changeMode = false;
    	this.defaultMode = true;
    	this.SELMode = false;
    	
    	this.updateView(true);
    	
    }
    
    
    /*
     * setting changeMode to false will get us back to the default. 
     */
    public void SELModeClicked() throws IOException
    {
    	
    	this.changeMode = false;
    	this.defaultMode = false;
    	this.SELMode = true;
    	
    	this.updateView(true);	
    	
    }
    
    
    /*
     * getter method to obtain the current mode, so that the trackViewPanel will know
     * the state of the current mode, and will print accordingly.  
     */
    public boolean getChangeMode()
    {
    	return this.changeMode;
    }
    
    public boolean getDefaultMode()
    {
    	return this.defaultMode;
    }
    
    public boolean getSELMode()
    {
    	return this.SELMode;
    }
    
    public boolean getHasReadLast()
    {
    	return this.hasReadLast;
    }
    
    public void setHasReadLast(boolean b)
    {
    	this.hasReadLast = b;
    }
    
    
    public void initSetRec() throws IOException
    {
    	double dist;
    	int length;
    	int width;
    	
    	double lat;
    	double lon;
    	
    	LatLon centerPoint;
    	
    	
    	String distValue = JOptionPane.showInputDialog("Input distance in degrees lat/lon: ");
       
    	if(distValue != null)
    	{
    		dist = Double.parseDouble(distValue);
    		String lenValue = JOptionPane.showInputDialog("Input Length ( In number of receptors ): ");
        	if(lenValue != null)
        	{
        		length = Integer.parseInt(lenValue);
        		String widthValue = JOptionPane.showInputDialog("Input Width ( In number of receptors ): ");
        		
            	if(widthValue != null)
            	{
            		width = Integer.parseInt(widthValue);
            		String centLatValue = JOptionPane.showInputDialog("Input Center Point lattitude: ");
            		
                	if(centLatValue != null)
                	{
                		lat = Double.parseDouble(centLatValue);
                		String centLonValue = JOptionPane.showInputDialog("Input Center Point longitude: ");
                    	if( centLonValue != null )
                    	{
                    		lon = Double.parseDouble(centLonValue);
                    		
                    		
                        	/*System.out.println(dist);
                        	System.out.println(length);
                        	System.out.println(width);
                        	System.out.println(lat);
                        	System.out.println(lon);*/
                    		
                    		
                    		File file = new File("src/NewReceptorGridFile");
                    		PrintWriter writer = new PrintWriter(file);
                    		writer.println("Latitude" + '\t' + "Longitude");
                    		
                    		
                    		double centLat = lat;
                    		double centLong = lon;
                    		
                    		
                    		double startLat = centLat - dist/2;
                    		double startLong = centLong - dist/2;
                    		
                    		
                    		//System.out.println(startLat);
                    		//System.out.println(startLong);
                    		
                    		for(int i = 0; i < length; i++)
                    		{
                    			double currLat = startLat + dist*i/length;
                    			//System.out.println(currLat);
                    			
                    			for(int j = 0; j < width; j++)
                    			{
                    				double currLong = startLong + dist*j/width;
                    				
                    				//System.out.println(currLong);
                    				
                    				Double la = new Double(currLat);
                    				Double lo = new Double(currLong);
                    				
                    				writer.print(currLat);
                    				writer.print('\t');
                    				writer.print(currLong);
                    				writer.print('\t');
                    				
                    				writer.println();
                    			}
                    		}
                    		
                    		
                    		writer.close();
                    	}

                    	
                    	//now we want to read the file that we wrote to. 
                    	
                    	
                    	clearReceptors();
                    	
                    	this.recFilePath = "src/NewReceptorGridFile";
                    	
                    	
                    	
                    	this.hasReadFile = false;
                    	
                    	updateView(true);

                    	}
                	}

            	}
        		
        	}
    	}
    	

    	
    	
    	
    
    
    
    public void initRecFile()
    {

    	recChooser = new JFileChooser();
		int returnVal = recChooser.showOpenDialog(this);

        if (returnVal == JFileChooser.APPROVE_OPTION) {
		
		recFilePath = recChooser.getSelectedFile().getAbsolutePath();
		
        }
        

    }
    
    
    
    public void initThrustFile()
    {
    	
    	this.thrustChooser = new JFileChooser();

		int returnVal = thrustChooser.showOpenDialog(this);

        if (returnVal == JFileChooser.APPROVE_OPTION) {
		
		thrustFilePath = thrustChooser.getSelectedFile().getAbsolutePath();
		
		
        }

    }
    
    
    public void initSandPFile() throws IOException
    {
    	this.sAndPChooser = new JFileChooser();

		int returnVal = sAndPChooser.showOpenDialog(this);

        if (returnVal == JFileChooser.APPROVE_OPTION) {
		
		sAndPFilePath = sAndPChooser.getSelectedFile().getAbsolutePath();
		
        }
        
        //now we want to create the SARTrack from the file chosen
        //and set that SARTrack to be the current SARTrack
        
        
       
		SARTrack currTrack = this.extractTrack();
			
		

        this.setCurrentTrack(currTrack);
        //then we will extract the speed, create a speed file, and then
        //set that to be the current speed file. 
        
        this.trackController.addTrack(currTrack);
    
        this.extractSpeed();
        this.trackViewPanel.setSpeedFilePath("src/speedFile.txt");
        this.trackViewPanel.readSpeed();
        
    }
    
    
    private SARTrack extractTrack() throws IOException
    {
    	
    	//System.out.println("starts extracting track");
    	SARTrack track = new SARTrack("track");
    	
    	BufferedReader reader = new BufferedReader(
	   				new FileReader(sAndPFilePath));

			
    	
			
			
		reader.readLine();// consume the first line of the file, it's
							// meant for labelling.

		int i = 0;
		String line;
		while ((line = reader.readLine()) != null) {

			
			//System.out.println(line);
			
			
			String lat = line.substring(0, line.indexOf('\t'));
	
				
			String rest = line.substring(line.indexOf('\t') + 1);
				
				
			String lon = rest.substring(0, rest.indexOf('\t'));
				
	
			String rest2 = rest.substring(rest.indexOf('\t') + 1);
	
			String alt = rest2.substring(0, rest2.indexOf('\t'));
	
				
			
				
				
	
				// at this point I have the lat and lon values for the first
				// point
	
			double la = Double.parseDouble(lat);
			double lo = Double.parseDouble(lon);
			double al = Double.parseDouble(alt);
	
			SARPosition rec = new SARPosition(Angle.fromDegrees(la),
						Angle.fromDegrees(lo), al);//now to read the file
		
			
			track.add(i, rec);
			i++;

		}
			
    	return track;
    	
    }
    
    private void extractSpeed() throws IOException
    {
    	
	    BufferedReader reader = new BufferedReader(
	   				new FileReader(sAndPFilePath));

	    
		File file = new File("src/speedFile.txt");
		PrintWriter writer = new PrintWriter(file);
		
		
		reader.readLine();// consume the first line of the file, it's
							// meant for labelling.
	
		writer.println("speed");
		
		int i = 0;
		String line;
		while ((line = reader.readLine()) != null) {
					
			int lastTab = line.lastIndexOf('\t');
		
				
			String speed = line.substring(lastTab + 1);
		
			double sp = Double.parseDouble( speed );
			
			writer.println(sp);

		}
    	
		writer.close();
    }
    
    
    public void resetHasReadFile()
    {
    	//this.clearReceptors();
    	this.hasReadFile = false;
    	this.hasReadLast = false;
    	this.hasReadThrust = false;
    }
    
  
   	/*
   	 * 
   	 */
   	protected void detReceptors( LatLon currPos , RenderableLayer layer ) throws IOException
   	{
   		
   		if(hasReadFile == false)
   		{
   			
 
   			
   		
   			
   			
   			BufferedReader reader = new BufferedReader(
   	   				new FileReader(recFilePath));

   			

   			
   			
   			reader.readLine();// consume the first line of the file, it's
   							// meant for labelling.

   			String line;
   			while ((line = reader.readLine()) != null) {

   		

   			String lat = line.substring(0, line.indexOf('\t'));// at the
   																// first
   																// instance
   																// of a
   																// tab,
   																// stop
   																// the
   																// substring.

   			String rest = line.substring(line.indexOf('\t') + 1);// dont'
   																	// want
   																	// to
   																	// include
   																	// the
   																	// actual
   																	// tab
   																	// so
   																	// +1

   	

   			String lon = rest.substring(0, rest.indexOf('\t'));

   			

   			// at this point I have the lat and lon values for the first
   			// point

   			double la = Double.parseDouble(lat);
   			double lo = Double.parseDouble(lon);

   			LatLon rec = new LatLon(Angle.fromDegrees(la),
   					Angle.fromDegrees(lo));
   			
   			
   			//Color currCol = detColor(currPos, rec);
   			//drawColor( currPos, rec, layer );//will want to draw out the colors as well at the beginning
   			
   			Receptor r = new Receptor(rec, Color.WHITE);//this is a dummy receptor that is used pretty much only
   													//because the method takes in a Receptor instead of a LatLon
   			double noiseLevel = detNoise(currPos, rec);
   			Color currCol = detColorMax(noiseLevel, r);
   			//drawColor2(noiseLevel, currPos, rec, layer);
   			
   			makeColor(rec.getLatitude(), rec.getLongitude(), layer, currCol);
   			grid.add( new Receptor( rec, currCol));
   			
   			
   				
   			
   			}
   		
   			hasReadFile = true;//note that the file should only ever be read once
   			
   			
   			
   			//System.out.println(grid.size());
   			
   			
   			
   			return;//should end the method here on the first trial.
   		}
   		
   		if(hasReadThrust == false)//this is done to make sure that we will only fill the decibels array once
   		{
   			readThrust();
   			hasReadThrust = true;
   		}
   		
		
   		for( Receptor r : grid )
   		{
   			double noiseLevel = detNoise(currPos, r.getLoc());
   			
   			r.setCurr(noiseLevel);
   			
   			
   			//r.addToHM(this.trackViewPanel.getCurrentPositionNumber(), noiseLevel);
   			
   			
   			if(this.prevPosition != null && this.hasReadLast == false)
   			{
   				
   				LatLon prev = new LatLon(prevPosition.latitude, prevPosition.longitude);
   				r.updateSEL(noiseLevel, prev, currPos, this.prevSpeed, true);//, this.trackViewPanel.getCurrentPositionNumber());
   				
   				
   				if(this.isLastPosition(this.getCurrentPositionNumber()))
   				{
   					this.hasReadLast = true;
   				}
   				
   			}
   			
   			Color cCol = detColorMax( noiseLevel, r);
   			if(r.getCol() != cCol )//if it's color has changed
   			{
   				r.setCol( cCol );//then we set R's recorded color in the array
   														//and update the color
	
   				//drawColor2( noiseLevel, currPos, r.getLoc(), layer , cCol);
   				makeColor(r.getLoc().getLatitude(), r.getLoc().getLongitude(), layer, cCol);
   			
   			}
   		}
   		
   
   	}
   	
   	protected double detNoise(LatLon planePos, LatLon rec)
   	{
   		
   		
   		
   		double dist = LatLon.greatCircleDistance(planePos, rec).radians
   				* Earth.WGS84_EQUATORIAL_RADIUS; // / ( 2 * Math.pow((Math.PI), 2.0) );
   		
   		//now to convert distance to feet so that it will fit in with the original model. 
   		
   		double fDist = dist * 3.28084;
   		
   		int count = 0; 
   		
   		while( count < 9 && fDist > dists[count])
   		{
   			count++;//find what point we are on in the index of dists
   		}
   		
   		count++; // we have to make sure that count is incremented, because in the decibels array we have an extra
   		//column that doesn't include any decibels. 
   		
   		double noiseLevel = 0; //= 999999999;//by this we more or less mean infinity
   		
   		
   		if(count == 1)
   		{
   			if(fDist < 10.0)
   			{
   				fDist = 10.0;//setting the distance equal to 10 feet if the distance is smaller than 10 feet. 
   			}
   			
   			noiseLevel = interpolateN2(1, fDist, count);//new method that is here specifically if the distance is less than 200 feet
   			

   			
   			
   		}
   		
   		
   		else
   		{
   			noiseLevel = interpolateNoise( 1, 1, fDist, count  );
   			
   		}
   		
   		return noiseLevel;
   	}
   	

   	/*
   	 * determines the color of any particular position relative to another position. Will be
   	 * red if < 1mi, yellow if < 2 mi and green for anything greater. 
   	 */
   	protected Color detColorMax(double noiseLevel, Receptor rec) throws IOException
   	{

   	    
   		
   		if(noiseLevel > rec.getMax())
   		{
   			rec.setMax(noiseLevel);//we have to make sure that we keep track of the max. 
   			
   			
   		}
   		//now if the max is greater than thresY then we have to just return red.
   		//this will set the max to where it should be. 
   		
   		
   		double noise;
   		
   		if(this.SELMode == true)
   		{
   			noise = rec.getSEL();//rec.calculateSEL(this.trackViewPanel.getCurrentPositionNumber());
   			if(noise == -1.0)
   			{
   				this.trackViewPanel.resetDefaultMode();
   				noise = noiseLevel;
   			}
   		}
   		
   		else if(this.changeMode == true)
   		{
   			noise = rec.getMax();
   		}
   		else
   		{
   			noise = noiseLevel;
   		}
   		
   		
   		if ( noise < thresG )//if it's not red, then we just go according to noiseLevel. 
		{
			return Color.GREEN;
		}

		else if ( noise < thresY )
				
				//decibels[1][count] < 90.0 )// 2 miles
		{
			return Color.YELLOW;
		}
   		
		else
		{
			return Color.red;
		}


   }
   	
   
   	
   	
   	/*
   	 * want this method to figure out what the noise level actually will be at the desired point. 
   	 * 
   	 * 
   	 */
   	
   	protected double interpolateNoise( int p1, int p2, double d,  int d2)
   	{
   	
   		double x = (decibels[p1][d2] - decibels[p1][d2 - 1])*(Math.log10(d) - Math.log10(dists[d2 - 2]));
   		
   		double y = Math.log10(dists[d2 - 1]) - Math.log10(dists[d2 - 2]);
   		
   		return decibels[p1][d2 - 1] + (x/y);
   		
   	}
   	
   	/*
   	 * want this method to figure out what the noise level actually will be at the desired point. 
   	 * 
   	 * 
   	 */
   	
   	protected double interpolateN2( int p1, double d,  int d2)
   	{
	
		//System.out.println( decibels[p1][1]);
		
		//System.out.println(d2);//should be like 10
		
		//System.out.println(decibels[p1][1] + 10*Math.log10(200/d));
		
   		return decibels[p1][1] + 10*Math.log10(200/d);//so for some reason, this is a very big number at certain points
   		
   		
   		
   	}
   	
   	
   	
   	/*
   	 * 
   	 */
   	
   	protected void readThrust() throws IOException
   	{
   		
   			
   			
   			/*BufferedReader reader = new BufferedReader(
   				new FileReader(
   						"C:\\Users\\Alexander Zhu\\Downloads\\JinhuaAIRNoise062014\\JinhuaAIRNoise062014\\CF565C.txt"));*/
   		
   		
   		BufferedReader reader = new BufferedReader(
   				new FileReader( this.thrustFilePath ));
   			reader.readLine();// consume the first line of the file, it's
   							// meant for labelling.
   			
   			//I'm going to create the full array in 1 swoop, even though for now I'm only using 1 row.

   			String line;
   			int row = 0;
   			
   			while ((line = reader.readLine()) != null) {

   		

   			String first = line.substring(0, line.indexOf('\t'));
   		

   			String fRest = line.substring(line.indexOf('\t') + 1);// dont'
   																	// want
   																	// to
   																	// include
   																	// the
   																	// actual
   																	// tab
   																	// so
   																	// +1
			first = fRest.substring(0, fRest.indexOf('\t'));//this will get me to the index of the second tab
			fRest = fRest.substring(fRest.indexOf('\t') + 1);// this is what comes right after the second tab
			
			first = fRest.substring(0, fRest.indexOf('\t'));//this will get me to the index of the second tab
			fRest = fRest.substring(fRest.indexOf('\t') + 1);// this is what comes right after the second tab
			
			
			//System.out.println(first);
   			
   				for(int col = 0; col < 11; col++)
   				{
   			
   					first = fRest.substring(0, fRest.indexOf('\t'));//this will get me to the index of the second tab
   					fRest = fRest.substring(fRest.indexOf('\t') + 1);// this is what comes right after the second tab
   					
   					//since each line in our document is separated by tabs, on each iteration we need to be getting
   					//to the next tab. This way we can have all the different 

   					decibels[row][col] = Double.parseDouble(first) ;//I believe this should actually be able to get
   										//the decibel value that I want. 
   					
   					//System.out.println(first);	
   				}
   			
   			
   			//System.out.println(row);
   			row++;

   			
   			}//at the end of all this the decibels 2d array
   			//should be completely filled the way I want it to be, and I should
   			//be able to access decibels from whatever other method I want. 
   			
   			
   			/*for(int i = 0; i < 20; i++)
   			{
   				
   				for(int j = 0; j < 11; j++)
   				{
   					System.out.print( decibels[i][j] + " " +" i,j values are: " + i + ", " + j + " |||");
   				}
   				System.out.println();
   			}*/
   			
   			

   	}
   	
   	
   	public void setRecSize( double d ) throws IOException
   	{
   		
   		this.recSize = d;
   		//this.clearReceptors();
   		this.updateView(true);  
   		
   	}
   	
   	
   	public double getRecSize()
   	{
   		
   		return this.recSize;
   	}
   	
   	
   	public void setShapeInd(int i) throws IOException
   	{
   		this.shapeInd = i;
   		
   		this.updateView(true);  
   	}
   	
   	public int getShapeInd()
   	{
   		return this.shapeInd;
   	}
   	
   	
   	
    protected void makeColor(Angle lat, Angle lon, RenderableLayer layer, Color c)
    {
      

      BasicShapeAttributes localBasicShapeAttributes = new BasicShapeAttributes();//setting the attributes of the shape

      
      localBasicShapeAttributes = new BasicShapeAttributes();
      
      Material m = new Material(c);
      localBasicShapeAttributes.setInteriorMaterial(m);
      localBasicShapeAttributes.setOutlineMaterial(new Material(WWUtil.makeColorBrighter(c)));
      localBasicShapeAttributes.setInteriorOpacity(0.5D);
      localBasicShapeAttributes.setOutlineOpacity(0.8D);
      localBasicShapeAttributes.setOutlineWidth(3.0D);
      
      LatLon newLoc = new LatLon(lat, lon);
      //Object localObject = new SurfaceCircle( newLoc , recSize);//construct the circle at the lat/lon that we pass in
      
      //System.out.println(shapeInd);
      
      if(shapeInd == 0)
      {
    	  localObject = new SurfaceCircle( newLoc , this.getRecSize());//construct the circle at the lat/lon that we pass in
      }
      
      else
      {
    	  localObject = new SurfaceSquare( newLoc , this.getRecSize());//for now, we can add any number of else ifs here for other shapes
    	  //if needed
      }
      
      
      ((SurfaceShape)localObject).setAttributes(localBasicShapeAttributes);
     
      
      if(hm.containsKey(newLoc))//if the key is already there, then clearly there is already a circle there
      {
     	 //layer.removeRenderable((Renderable)hm.get(newLoc));//remove the circle
     	 
     	 
     	 hm.get(newLoc).setVisible(false);
          layer.addRenderable((Renderable) localObject);//add in the new one on the worldwind map
          
          
          hm.remove(newLoc);//remove the old pair at the previous location
          hm.put(newLoc, (SurfaceShape) localObject);//add a new circle paired with the location to the hashmap
          
          //System.out.println(hm.size());
      }
      
      else//in this case, clearly there does not exist a circle at the desired point just yet, so we only need to worry
     	 //about adding to the layer and the hashmap. 
      {
     	 layer.addRenderable((Renderable) localObject);//add in the new one on the worldwind map
     	 hm.put(newLoc, (SurfaceShape) localObject);//add a new circle paird with the location to the hashmap
     	 
          //System.out.println(hm.size());
      }
    }  	
       
    
    private void clearReceptors()
    {
    	
    	for(Receptor r : this.grid)
    	{
    		hm.get( r.getLoc() ).setVisible(false);
    		
    	}
    	
    	hm.clear();
    	grid.clear();
    }
    
       
     

       
    

    private void saveExamineViewState()
    {
        this.examineViewState = new ViewState((OrbitView) this.wwd.getView(), this.getHeading(),
            this.getPositionAlongSegment());
        //System.out.println("AnalysisPanel.saveExamineViewState(): Saved examine view state.");
    }

    private int getCurrentPositionNumber()
    {
        return this.trackViewPanel.getCurrentPositionNumber();
    }

    private boolean isLastPosition(int n)
    {
        return n >= this.currentTrack.size() - 1;
    }

    public void gotoTrackEnd()
    {
        this.trackViewPanel.gotoTrackEnd();
    }
    
    public void gotoTrackStart()
    {
    	this.trackViewPanel.gotoTrackStart();
    }

    public Position getCurrentSegmentStartPosition()
    {
        int n = this.getCurrentPositionNumber();
        return getSegmentStartPosition(n);
    }

    public Position getSegmentStartPosition(int startPositionNumber)
    {
        if (this.currentTrack == null || this.currentTrack.size() == 0)
            return null;

        Position pos;
        if (isLastPosition(startPositionNumber))
            pos = this.currentTrack.get(this.currentTrack.size() - 1);
        else
            pos = this.currentTrack.get(startPositionNumber);

        return new Position(pos.getLatitude(), pos.getLongitude(), pos.getElevation() + this.currentTrack.getOffset());
    }

    public Position getCurrentSegmentEndPosition()
    {
        int n = this.getCurrentPositionNumber();
        return getSegmentEndPosition(n);
    }

    public Position getSegmentEndPosition(int startPositionNumber)
    {
        if (this.currentTrack == null || this.currentTrack.size() == 0)
            return null;

        Position pos;
        if (isLastPosition(startPositionNumber + 1))
            pos = this.currentTrack.get(this.currentTrack.size() - 1);
        else
            pos = this.currentTrack.get(startPositionNumber + 1);

        return new Position(pos.getLatitude(), pos.getLongitude(), pos.getElevation() + this.currentTrack.getOffset());
    }

    public double getSegmentLength(int startPositionNumber)
    {
        Vec4 start = wwd.getModel().getGlobe().computePointFromPosition(getSegmentStartPosition(startPositionNumber));
        Vec4 end = wwd.getModel().getGlobe().computePointFromPosition(getSegmentEndPosition(startPositionNumber));
        return start.distanceTo3(end);
    }

    public Position getPositionAlongSegment()
    {
        double t = this.trackViewPanel.getPositionDelta();
        return this.getPositionAlongSegment(t);
    }

    private Position getPositionAlongSegment(double t)
    {
        Position pa = this.getCurrentSegmentStartPosition();
        if (pa == null)
            return null;
        Position pb = this.getCurrentSegmentEndPosition();
        if (pb == null)
            return pa;

        return interpolateTrackPosition(t, pa, pb);
    }

    public Angle getHeading()
    {
        return getHeading(this.getCurrentPositionNumber());
    }

    public Angle getHeading(int cpn)
    {
        Position pA;
        Position pB;

        if ((cpn < 1) && (this.isLastPosition(cpn))) //handle first position
            return Angle.ZERO;
        else if (!this.isLastPosition(cpn))
        {
            pA = this.currentTrack.get(cpn);
            pB = this.currentTrack.get(cpn + 1);
        }
        else
        {
            pA = this.currentTrack.get(cpn - 1);
            pB = this.currentTrack.get(cpn);
        }

        return LatLon.greatCircleAzimuth(pA, pB);
    }

    // Interpolate heading at track jonctions
    private Angle getSmoothedHeading(double dt)
    {
        int cpn = this.getCurrentPositionNumber();
        Angle heading1, heading2;
        double t1, t;
        // Current segment
        heading1 = getHeading(cpn);
        t1 = this.trackViewPanel.getPositionDelta();
        if (t1 <= dt && cpn > 0)
        {
            heading2 = getHeading(cpn - 1);
            t = (1 - t1 / dt) * .5;
        }
        else if (t1 >= (1 - dt) && !this.isLastPosition(cpn))
        {
            heading2 = getHeading(cpn + 1);
            t = (1 - (1 - t1) / dt) * .5;
        }
        else
            return heading1;

        return Angle.mix(t, heading1, heading2);
    }

    @SuppressWarnings({"UnusedDeclaration"})
    private Position getGroundPositionAlongSegment()
    {
        if (this.wwd == null)
            return null;

        Position pos = getPositionAlongSegment();
        if (pos == null)
            return null;

        return getGroundPosition(pos);
    }

    private Position getGroundPosition(LatLon location)
    {
        double elevation = this.wwd.getModel().getGlobe().getElevation(location.getLatitude(), location.getLongitude());
        return new Position(location, elevation);
    }

    // TODO: weighted average should be over actual polyline track points
    private Position getSmoothedGroundPositionAlongSegment()
    {
        if (this.currentTrack == null || this.currentTrack.size() == 0)
            return null;

        Position start = getCurrentSegmentStartPosition();
        Position end = getCurrentSegmentEndPosition();
        if (start == null || end == null)
            return null;

        Globe globe = this.wwd.getModel().getGlobe();
        if (globe == null)
            return null;

        int n = this.getCurrentPositionNumber();
        double t = this.trackViewPanel.getPositionDelta();
        // Limit t to 0 if this is the last position.
        if (isLastPosition(n))
            t = 0;

        double tstep = 1 / 100.0;
        int numWeights = 15; // TODO: extract to configurable property

        double elev = 0;
        double sumOfWeights = 0;
        // Compute the moving weighted average of track positions on both sides of the current track position.
        for (int i = 0; i < numWeights; i++)
        {
            double tt;
            Position pos;

            // Previous ground positions.
            tt = t - i * tstep;
            pos = null;
            if (tt >= 0) // Position is in the current track segment.
                pos = interpolateTrackPosition(tt, start, end);
            else if (tt < 0 && n > 0) // Position is in the previous track segment.
                pos = interpolateTrackPosition(tt + 1, this.currentTrack.get(n - 1), start);
            if (pos != null)
            {
                double e = globe.getElevation(pos.getLatitude(), pos.getLongitude());
                elev += (numWeights - i) * e;
                sumOfWeights += (numWeights - i);
            }

            // Next ground positions.
            // We don't want to count the first position twice.
            if (i != 0)
            {
                tt = t + i * tstep;
                pos = null;
                if (tt <= 1) // Position is in the current track segment.
                    pos = interpolateTrackPosition(tt, start, end);
                else if (tt > 1 && !isLastPosition(n + 1)) // Position is in the next track segment.
                    pos = interpolateTrackPosition(tt - 1, end, this.currentTrack.get(n + 2));
                if (pos != null)
                {
                    double e = globe.getElevation(pos.getLatitude(), pos.getLongitude());
                    elev += (numWeights - i) * e;
                    sumOfWeights += (numWeights - i);
                }
            }
        }
        elev /= sumOfWeights;

        Position actualPos = interpolateTrackPosition(t, start, end);
        return new Position(actualPos, elev);
    }

    /**
     * SAR tracks points are connected with lines of constant heading (rhumb lines). In order to compute an interpolated
     * position between two track points, we must use rhumb computations, rather than linearly interpolate the
     * position.
     *
     * @param t     a decimal number between 0 and 1
     * @param begin first position
     * @param end   second position
     *
     * @return Position in between begin and end
     */
    private Position interpolateTrackPosition(double t, Position begin, Position end)
    {
        if (begin == null || end == null)
            return null;

        // The track is drawn as a rhumb line, therefore we use rhumb computations to interpolate between the track's
        // geographic positions.
        return Position.interpolateRhumb(t, begin, end);
    }

//    /**
//     * Compute crosshair location in viewport for 'follow' - 'fly-it' mode.
//     * <p>
//     * It computes the intersection of the air track with the near clipping plane
//     * and determines the corresponding crosshair position in the viewport.</p>
//     * <p>
//     * This assumes the view is headed in the same direction as the air track,
//     * and the eye is set to look at the aircraft from a distance and angle.</p>
//     *
//     * @param view the current <code>View</code>
//     * @param a view pitch angle relative to the air track (0 degree = horizontal)
//     * @param distance eye distance from the aircraft
//     * @return the crosshair center position in the viewport.
//     */
//    private Vec4 computeCrosshairPosition(View view, Angle a, double distance)
//    {
//        double hfovH = view.getFieldOfView().radians / 2; // half horizontal fov in radians
//        double hw = view.getViewport().width / 2;         // half viewport width
//        double hh = view.getViewport().height / 2;        // half viewport height
//        double d = hw / Math.tan(hfovH);                  // distance to viewport plane in pixels
//        // distance to near plane in meters
//        double dNearMeter = Math.abs(view.getFrustum().getNear().getDistance());
//        // crosshair elevation above viewport center in meter
//        double dyMeter = (dNearMeter - distance) * Math.sin(a.radians);
//        // corresponding vertical fov half angle
//        double ay = Math.atan(dyMeter / dNearMeter);
//        // corresponding viewport crosshair elevation in pixels
//        double dy = Math.tan(ay) * d;
//        // final crosshair viewport position
//        return new Vec4(hw, hh + dy, 0, 0);
//    }

    // Mark crosshair as needing update after next render pass

    private void updateCrosshair()
    {
        this.crosshairNeedsUpdate = true;
        this.wwd.redraw();
    }

    // Update crosshair position to follow the air track
    private void doUpdateCrosshair()
    {
        Vec4 crosshairPos = computeCrosshairPosition();
        if (crosshairPos != null)
        {
            this.crosshairLayer.setEnabled(true);
            this.crosshairLayer.setLocationCenter(crosshairPos);
        }
        else
        {
            this.crosshairLayer.setEnabled(false);
        }
        this.crosshairNeedsUpdate = false;
    }

    private void updateShowTrackInformation()
    {
        if (this.trackInfoState != null && this.trackInfoState.equals(TrackViewPanel.CURRENT_SEGMENT)
            && !this.trackViewPanel.isFollowViewMode())
        {
            this.segmentInfo.setEnabled(true);
        }
        else
        {
            this.segmentInfo.setEnabled(false);
        }
    }

    // Compute cartesian intersection between the current air track segment and the near plane.
    // Follow rhumb line segments.
    private Vec4 computeCrosshairPosition()
    {
        Position posA = getCurrentSegmentStartPosition();
        Position posB = getCurrentSegmentEndPosition();
        Angle segmentAzimuth = LatLon.rhumbAzimuth(posA, posB);
        Angle segmentDistance = LatLon.rhumbDistance(posA, posB);
        int numSubsegments = 10;  // TODO: get from track polyline
        double step = 1d / numSubsegments;
        // Extend the track segment ends by one subsegment to make sure it will intersect the near plane
        double deltaElevation = posB.getElevation() - posA.getElevation();
        LatLon latLon = LatLon.rhumbEndPosition(posA, segmentAzimuth.addRadians(Math.PI),
            Angle.fromRadians(segmentDistance.radians / numSubsegments));
        posA = new Position(latLon, posA.getElevation() - deltaElevation / numSubsegments);
        latLon = LatLon.rhumbEndPosition(posB, segmentAzimuth,
            Angle.fromRadians(segmentDistance.radians / numSubsegments));
        posB = new Position(latLon, posB.getElevation() + deltaElevation / numSubsegments);
        segmentDistance = LatLon.rhumbDistance(posA, posB);
        // Iterate through segments to find intersection
        Globe globe = this.wwd.getModel().getGlobe();
        Plane near = this.wwd.getView().getFrustumInModelCoordinates().getNear();
        Position p1 = null, p2;
        for (double s = 0; s <= 1; s += step)
        {
            if (s == 0)
                p2 = posA;
            else if (s >= 1)
                p2 = posB;
            else
            {
                Angle distance = Angle.fromRadians(s * segmentDistance.radians);
                latLon = LatLon.rhumbEndPosition(posA, segmentAzimuth, distance);
                p2 = new Position(latLon, (1 - s) * posA.getElevation() + s * posB.getElevation());
            }
            if (p1 != null)
            {
                Vec4 pa = globe.computePointFromPosition(p1);
                Vec4 pb = globe.computePointFromPosition(p2);
                if (pa.distanceTo3(pb) > 0)
                {
                    Vec4 intersection = near.intersect(pa, pb);
                    if (intersection != null)
                    {
                        return this.wwd.getView().project(intersection);
                    }
                }
            }
            p1 = p2;
        }
        return null;
    }

    protected void initComponents()
    {
        this.trackViewPanel = new TrackViewPanel(this);
    }

    protected void layoutComponents()
    {
        this.setLayout(new BorderLayout(0, 0)); // hgap vgap

        // Put the panel in the north region to keep its components from expanding vertically.
        this.add(this.trackViewPanel, BorderLayout.NORTH);
    }

    // *** Restorable interface ***

    public String getRestorableState()
    {
        RestorableSupport rs = RestorableSupport.newRestorableSupport();
        this.doGetRestorableState(rs, null);

        return rs.getStateAsXml();
    }

    public void restoreState(String stateInXml)
    {
        if (stateInXml == null)
        {
            String message = Logging.getMessage("nullValue.StringIsNull");
            Logging.logger().severe(message);
            throw new IllegalArgumentException(message);
        }

        RestorableSupport rs;
        try
        {
            rs = RestorableSupport.parse(stateInXml);
        }
        catch (Exception e)
        {
            // Parsing the document specified by stateInXml failed.
            String message = Logging.getMessage("generic.ExceptionAttemptingToParseStateXml", stateInXml);
            Logging.logger().severe(message);
            throw new IllegalArgumentException(message, e);
        }

        this.doRestoreState(rs, null);
    }

    protected void doGetRestorableState(RestorableSupport rs, RestorableSupport.StateObject context)
    {
        // Save examine view mode state if view is currently in examine mode.
        if (TrackViewPanel.VIEW_MODE_EXAMINE.equals(this.trackViewPanel.getViewMode()))
            this.saveExamineViewState();
        // Add state values
        if (this.examineViewState != null)
        {
            rs.addStateValueAsDouble(context, "examinePitch", this.examineViewState.pitch.getDegrees());
            rs.addStateValueAsDouble(context, "examineRelativeHeading",
                this.examineViewState.relativeHeading.getDegrees());
            rs.addStateValueAsDouble(context, "examineZoom", this.examineViewState.zoom);
            rs.addStateValueAsLatLon(context, "examineCenter", this.examineViewState.relativeCenterLocation);
        }
        if (this.trackViewPanel != null)
            this.trackViewPanel.doGetRestorableState(rs, rs.addStateObject(context, "trackView"));

        if (this.terrainProfilePanel != null)
            this.terrainProfilePanel.doGetRestorableState(rs, rs.addStateObject(context, "terrainProfile"));

        if (this.cloudCeilingPanel != null)
            this.cloudCeilingPanel.doGetRestorableState(rs, rs.addStateObject(context, "cloudCeiling"));
    }

    protected void doRestoreState(RestorableSupport rs, RestorableSupport.StateObject context)
    {
        // Retrieve state values
        Double examinePitchState = rs.getStateValueAsDouble(context, "examinePitch");
        Double examineRelativeHeadingState = rs.getStateValueAsDouble(context, "examineRelativeHeading");
        Double examineZoomState = rs.getStateValueAsDouble(context, "examineZoom");
        LatLon examineCenterState = rs.getStateValueAsLatLon(context, "examineCenter");
        if (examinePitchState != null && examineRelativeHeadingState != null && examineZoomState != null
            && examineCenterState != null)
        {
            this.examineViewState = new ViewState(Angle.fromDegrees(examineRelativeHeadingState),
                Angle.fromDegrees(examinePitchState), examineZoomState, examineCenterState);
            // this prevents the restored examine view state from being overwritten at next view update.
            this.lastUpdateViewMode = null;
        }

        RestorableSupport.StateObject trackViewState = rs.getStateObject(context, "trackView");
        if (trackViewState != null && this.trackViewPanel != null)
        	
            
        
            
            this.trackViewPanel.doRestoreState(rs, trackViewState);
        
        

        RestorableSupport.StateObject terrainProfileState = rs.getStateObject(context, "terrainProfile");
        if (terrainProfileState != null && this.terrainProfilePanel != null)
            this.terrainProfilePanel.doRestoreState(rs, terrainProfileState);

        if (this.cloudCeilingPanel != null && this.currentTrack != null)
            this.cloudCeilingPanel.setTrackCurrentPositionNumber(this.getCurrentPositionNumber());

        RestorableSupport.StateObject cloudCeilingState = rs.getStateObject(context, "cloudCeiling");
        if (cloudCeilingState != null && this.cloudCeilingPanel != null)
            this.cloudCeilingPanel.doRestoreState(rs, cloudCeilingState);
    }
}
